# Seeu Coffee – Sistem Informasi Manajemen Berbasis Komponen

Vue 3 (`<script setup>`) + Vue Router + Pinia. Data awal dari `src/seed/*.json` dimuat otomatis ke
localStorage saat pertama kali dijalankan, dan semua perubahan (tambah/ubah/hapus produk, transaksi,
status) tersimpan permanen.

## Menjalankan
```bash
npm install
npm run dev
```
> **Catatan Windows PowerShell**: Jika muncul pesan error `cannot be loaded because running scripts is disabled on this system`, jalankan dengan:
> ```powershell
> npm.cmd run dev
> ```
> atau jalankan perintah ini sekali di PowerShell:
> ```powershell
> Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
> ```

## Akun demo
| Role | Username | Kata sandi |
|---|---|---|
| Pemilik | owner | owner123 |
| Kasir | kasir1 | kasir123 |
| Pelanggan | pelanggan1 | pelanggan123 |

## Catatan
- Ganti isi `src/seed/products.json` dengan menu asli Seeu Coffee.
- Reset data: hapus key `seeu_*` di DevTools > Application > Local Storage, lalu muat ulang.
