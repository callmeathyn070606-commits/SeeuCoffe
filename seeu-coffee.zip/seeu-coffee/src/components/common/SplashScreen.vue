<template>
  <main class="splash-screen" role="status" aria-label="Memuat SeeU Coffee">
    <div class="splash-content">
      <div class="splash-logo-frame">
        <img class="splash-logo" src="/seeu-coffee-logo.png" alt="Logo Seeú Coffee & Space" />
      </div>
      <p class="splash-tagline">COFFEE · NATURE · GOOD MOMENTS</p>
      <div class="loading-track" aria-hidden="true">
        <span class="loading-progress"></span>
      </div>
      <p class="loading-label">Menyiapkan pengalaman terbaik untuk Anda...</p>
    </div>
    <span class="splash-leaf splash-leaf-left" aria-hidden="true"></span>
    <span class="splash-leaf splash-leaf-right" aria-hidden="true"></span>
  </main>
</template>

<script setup>
import { onMounted, onUnmounted } from 'vue'

const emit = defineEmits(['complete'])
let timer

onMounted(() => {
  timer = window.setTimeout(() => emit('complete'), 1800)
})

onUnmounted(() => {
  window.clearTimeout(timer)
})
</script>

<style scoped>
.splash-screen {
  position: fixed;
  inset: 0;
  z-index: 1000;
  display: grid;
  place-items: center;
  overflow: hidden;
  background:
    radial-gradient(ellipse at 50% 42%, rgba(77, 145, 83, 0.3), transparent 38%),
    linear-gradient(145deg, #071b12 0%, #0d2a1b 48%, #082016 100%);
  animation: splash-fade-in 0.45s ease-out both;
}

.splash-content {
  position: relative;
  z-index: 1;
  width: min(620px, 88vw);
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.splash-logo-frame {
  width: 100%;
  padding: clamp(0.7rem, 2.4vw, 1.35rem);
  border: 1px solid rgba(229, 239, 213, 0.84);
  border-radius: clamp(1.1rem, 3.5vw, 1.8rem);
  background: linear-gradient(145deg, #f3f5e9, #dce7cf);
  box-shadow:
    0 24px 60px rgba(0, 0, 0, 0.32),
    inset 0 1px 0 rgba(255, 255, 255, 0.9);
}

.splash-logo {
  width: min(100%, 560px);
  max-height: 48vh;
  object-fit: contain;
  filter: drop-shadow(0 18px 34px rgba(0, 0, 0, 0.34));
  animation: logo-breathe 2.2s ease-in-out infinite;
}

.splash-tagline {
  margin-top: 1.1rem;
  color: #c6dfbd;
  font-size: clamp(0.65rem, 2vw, 0.82rem);
  font-weight: 700;
  letter-spacing: 0.2em;
}

.loading-track {
  width: min(210px, 55vw);
  height: 3px;
  margin-top: 2rem;
  overflow: hidden;
  border-radius: 999px;
  background: rgba(215, 235, 206, 0.18);
}

.loading-progress {
  display: block;
  width: 42%;
  height: 100%;
  border-radius: inherit;
  background: linear-gradient(90deg, #a4c783, #e0d99c);
  animation: loading-slide 1.15s ease-in-out infinite;
}

.loading-label {
  margin-top: 0.8rem;
  color: rgba(235, 243, 224, 0.68);
  font-size: 0.78rem;
  letter-spacing: 0.03em;
}

.splash-leaf {
  position: absolute;
  width: clamp(100px, 18vw, 220px);
  height: clamp(140px, 24vw, 280px);
  opacity: 0.14;
  background:
    radial-gradient(ellipse 20px 46px at 28% 22%, #b4d48e 0 58%, transparent 62%),
    radial-gradient(ellipse 18px 42px at 54% 38%, #8fb978 0 58%, transparent 62%),
    radial-gradient(ellipse 18px 40px at 34% 56%, #bdd99b 0 58%, transparent 62%),
    radial-gradient(ellipse 17px 38px at 63% 73%, #8fb978 0 58%, transparent 62%),
    linear-gradient(132deg, transparent 49.4%, rgba(182, 211, 147, 0.8) 49.8% 50.2%, transparent 50.6%);
}

.splash-leaf-left {
  bottom: -3rem;
  left: -2rem;
  transform: rotate(28deg);
}

.splash-leaf-right {
  top: -3rem;
  right: -2rem;
  transform: rotate(208deg);
}

@keyframes splash-fade-in {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes logo-breathe {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.025); }
}

@keyframes loading-slide {
  from { transform: translateX(-110%); }
  to { transform: translateX(250%); }
}

@media (prefers-reduced-motion: reduce) {
  .splash-screen,
  .splash-logo,
  .loading-progress {
    animation: none;
  }
}
</style>
