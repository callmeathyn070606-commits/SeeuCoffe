<script setup>
import BaseButton from './BaseButton.vue'

defineProps({
  show: { type: Boolean, default: false },
  message: { type: String, default: 'Yakin melanjutkan?' }
})
defineEmits(['confirm', 'cancel'])
</script>

<template>
  <div v-if="show" class="modal-overlay" role="dialog" aria-modal="true">
    <div class="modal">
      <h2>Konfirmasi</h2>
      <p style="margin-top: 8px">{{ message }}</p>
      <div class="modal-actions">
        <BaseButton variant="ghost" @click="$emit('cancel')">Batal</BaseButton>
        <BaseButton variant="danger" @click="$emit('confirm')">Ya, hapus</BaseButton>
      </div>
    </div>
  </div>
</template>
