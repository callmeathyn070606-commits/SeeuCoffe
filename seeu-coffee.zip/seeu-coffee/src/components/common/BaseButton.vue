<script setup>
defineProps({
  variant: { type: String, default: 'primary' },
  size: { type: String, default: '' },
  type: { type: String, default: 'button' },
  disabled: { type: Boolean, default: false }
})
defineEmits(['click'])
</script>

<template>
  <button
    :type="type"
    :disabled="disabled"
    :class="['btn', `btn-${variant}`, { 'btn-sm': size === 'sm' }]"
    @click="$emit('click', $event)"
  >
    <slot />
  </button>
</template>
