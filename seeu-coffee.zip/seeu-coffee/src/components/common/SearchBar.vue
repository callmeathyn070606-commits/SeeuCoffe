<script setup>
defineProps({
  modelValue: { type: String, default: '' },
  placeholder: { type: String, default: 'Cari...' }
})
defineEmits(['update:modelValue'])
</script>

<template>
  <input
    type="search"
    :value="modelValue"
    :placeholder="placeholder"
    :aria-label="placeholder"
    @input="$emit('update:modelValue', $event.target.value)"
  />
</template>
