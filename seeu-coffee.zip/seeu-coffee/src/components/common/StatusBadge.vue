<script setup>
import { computed } from 'vue'
import { PAYMENT_STATUS, ORDER_STATUS } from '@/constants'

const props = defineProps({
  status: { type: String, required: true },
  kind: { type: String, default: 'order', validator: (v) => ['order', 'payment'].includes(v) }
})

const info = computed(() => {
  const list = props.kind === 'payment' ? PAYMENT_STATUS : ORDER_STATUS
  return list.find((s) => s.value === props.status) ?? { label: props.status, variant: 'info' }
})
</script>

<template>
  <span :class="['badge', `badge-${info.variant}`]">{{ info.label }}</span>
</template>
