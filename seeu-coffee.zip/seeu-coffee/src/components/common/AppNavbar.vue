<template>
  <nav class="navbar">
    <router-link to="/" class="brand">SeeU Coffee</router-link>
    <div class="nav-links">
      <router-link v-for="n in links" :key="n.to" :to="n.to">{{ n.label }}</router-link>
      <span class="nav-user" v-if="auth.user">{{ auth.user.name }}</span>
      <router-link v-if="!auth.isLoggedIn" class="staff-login" to="/">Keluar</router-link>
      <button v-if="auth.isLoggedIn" class="logout" @click="logout">Keluar</button>
    </div>
  </nav>
</template>

<script setup>
import { computed } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { NAV_BY_ROLE } from '@/constants'

const auth = useAuthStore()
const router = useRouter()
const links = computed(() => NAV_BY_ROLE[auth.user?.role] || [
  { to: '/katalog', label: 'Katalog' },
  { to: '/status', label: 'Status Pesanan' }
])

function logout () { auth.logout(); router.push('/login') }
</script>

<style scoped>
.nav-user {
  font-size: 0.8rem;
  color: rgba(255,255,255,0.5);
  padding: 0.3rem 0.6rem;
  border-left: 1px solid rgba(255,255,255,0.1);
  margin-left: 0.5rem;
}
</style>
