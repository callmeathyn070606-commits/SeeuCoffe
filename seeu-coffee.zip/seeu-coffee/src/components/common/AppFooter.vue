<template>
  <footer class="app-footer">
    <div class="footer-content">
      <span class="footer-brand"><span class="footer-leaf">♧</span> SeeU Coffee</span>
      <p>&copy; {{ year }} SeeU Coffee &mdash; Sistem Manajemen Kedai Kopi</p>
    </div>
  </footer>
</template>

<script setup>
const year = new Date().getFullYear()
</script>

<style scoped>
.footer-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.4rem;
}
.footer-brand {
  font-family: 'Poppins', sans-serif;
  font-weight: 600;
  font-size: 1rem;
  color: #7d806f;
}
.footer-leaf {
  display: inline-block;
  color: #91a78a;
  margin-right: 0.15rem;
  transform: rotate(-12deg);
}
</style>
