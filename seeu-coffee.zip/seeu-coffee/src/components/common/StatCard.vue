<script setup>
defineProps({
  title: { type: String, required: true },
  value: { type: [String, Number], required: true }
})
</script>

<template>
  <div class="card">
    <p class="muted text-small">{{ title }}</p>
    <p class="stat-value">{{ value }}</p>
  </div>
</template>

<style scoped>
.stat-value { font-family: var(--font-heading); font-size: 26px; font-weight: 700; color: var(--primary); }
</style>
