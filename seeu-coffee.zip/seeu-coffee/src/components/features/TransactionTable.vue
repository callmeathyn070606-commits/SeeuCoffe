<script setup>
import { rupiah, formatDate } from '@/utils/format'
import { PAYMENT_METHODS, ORDER_STATUS } from '@/constants'
import StatusBadge from '@/components/common/StatusBadge.vue'
import BaseButton from '@/components/common/BaseButton.vue'

defineProps({
  transactions: { type: Array, required: true },
  showActions: { type: Boolean, default: false }
})
defineEmits(['update-status', 'print'])

const methodLabel = (v) => PAYMENT_METHODS.find((m) => m.value === v)?.label ?? v

function nextOrderStatus(current) {
  const index = ORDER_STATUS.findIndex((s) => s.value === current)
  return ORDER_STATUS[index + 1] ?? null
}
</script>

<template>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Kode</th><th>Waktu</th><th>Pelanggan</th><th>Metode</th><th class="num">Total</th>
          <th>Pembayaran</th><th>Pesanan</th><th v-if="showActions">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="t in transactions" :key="t.id">
          <td>{{ t.code }}</td>
          <td>{{ formatDate(t.created_at) }}</td>
          <td>{{ t.customer_name }}</td>
          <td>{{ methodLabel(t.payment_method) }}</td>
          <td class="num">{{ rupiah(t.total) }}</td>
          <td><StatusBadge kind="payment" :status="t.payment_status" /></td>
          <td><StatusBadge kind="order" :status="t.order_status" /></td>
          <td v-if="showActions">
            <div class="row-actions">
              <BaseButton
                v-if="t.payment_status !== 'lunas'"
                variant="secondary" size="sm"
                @click="$emit('update-status', t.id, { payment_status: 'lunas' })"
              >Tandai lunas</BaseButton>
              <BaseButton
                v-if="nextOrderStatus(t.order_status)"
                variant="ghost" size="sm"
                @click="$emit('update-status', t.id, { order_status: nextOrderStatus(t.order_status).value })"
              >{{ nextOrderStatus(t.order_status).label }}</BaseButton>
              <BaseButton variant="ghost" size="sm" @click="$emit('print', t)">Cetak nota</BaseButton>
            </div>
          </td>
        </tr>
        <tr v-if="!transactions.length">
          <td :colspan="showActions ? 8 : 7" class="muted">Belum ada transaksi.</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
