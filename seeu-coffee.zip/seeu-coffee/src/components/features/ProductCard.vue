<script setup>
import { computed } from 'vue'
import { rupiah } from '@/utils/format'
import { LOW_STOCK_LIMIT } from '@/constants'
import { useProductStore } from '@/stores/product'
import BaseButton from '@/components/common/BaseButton.vue'

const props = defineProps({
  product: { type: Object, required: true },
  showAction: { type: Boolean, default: false }
})
defineEmits(['add-to-cart'])

const productStore = useProductStore()
const soldOut = computed(() => props.product.stock <= 0)
const lowStock = computed(() => !soldOut.value && props.product.stock <= LOW_STOCK_LIMIT)
</script>

<template>
  <article class="card product">
    <p class="muted text-small">{{ productStore.categoryName(product.category_id) }}</p>
    <h2>{{ product.name }}</h2>
    <p class="price">{{ rupiah(product.price) }}</p>
    <p class="text-small" :class="{ danger: soldOut, warn: lowStock }">
      {{ soldOut ? 'Stok habis' : `Stok: ${product.stock}` }}
    </p>
    <BaseButton v-if="showAction" :disabled="soldOut" @click="$emit('add-to-cart', product)">
      Tambah ke pesanan
    </BaseButton>
  </article>
</template>

<style scoped>
.product { display: grid; gap: 6px; align-content: start; }
.price { font-weight: 600; color: var(--primary); }
.danger { color: var(--danger); }
.warn { color: #B26A00; }
</style>
