<script setup>
import { rupiah } from '@/utils/format'
import { useProductStore } from '@/stores/product'
import BaseButton from '@/components/common/BaseButton.vue'

defineProps({ products: { type: Array, required: true } })
defineEmits(['edit', 'delete'])

const productStore = useProductStore()
</script>

<template>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Nama</th><th>Kategori</th><th class="num">Harga</th><th class="num">Stok</th><th>Status</th><th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="p in products" :key="p.id">
          <td>{{ p.name }}</td>
          <td>{{ productStore.categoryName(p.category_id) }}</td>
          <td class="num">{{ rupiah(p.price) }}</td>
          <td class="num">{{ p.stock }}</td>
          <td>
            <span :class="['badge', p.is_active ? 'badge-success' : 'badge-danger']">
              {{ p.is_active ? 'Tampil' : 'Disembunyikan' }}
            </span>
          </td>
          <td>
            <div class="row-actions">
              <BaseButton variant="ghost" size="sm" @click="$emit('edit', p)">Ubah</BaseButton>
              <BaseButton variant="danger" size="sm" @click="$emit('delete', p)">Hapus</BaseButton>
            </div>
          </td>
        </tr>
        <tr v-if="!products.length">
          <td colspan="6" class="muted">Belum ada produk. Tambahkan produk pertama Anda.</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
