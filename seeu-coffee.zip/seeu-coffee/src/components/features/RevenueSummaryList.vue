<script setup>
import { rupiah } from '@/utils/format'

defineProps({ rows: { type: Array, required: true } })

const label = (key) => new Date(key).toLocaleDateString('id-ID', { dateStyle: 'full', timeZone: 'UTC' })
</script>

<template>
  <ul class="rev">
    <li v-for="r in rows" :key="r.date">
      <span>{{ label(r.date) }}</span>
      <strong>{{ rupiah(r.total) }}</strong>
    </li>
    <li v-if="!rows.length" class="muted">Belum ada pendapatan dari transaksi lunas.</li>
  </ul>
</template>

<style scoped>
.rev { list-style: none; padding: 0; display: grid; gap: 8px; }
.rev li { display: flex; justify-content: space-between; border-bottom: 1px solid var(--border); padding-bottom: 6px; }
</style>
