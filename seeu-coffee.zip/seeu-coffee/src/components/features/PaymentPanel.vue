<script setup>
import { ref } from 'vue'
import { rupiah } from '@/utils/format'
import { PAYMENT_METHODS } from '@/constants'
import BaseButton from '@/components/common/BaseButton.vue'

defineProps({
  total: { type: Number, required: true },
  message: { type: Object, default: null }
})
const emit = defineEmits(['submit'])

const customerName = ref('')
const paymentMethod = ref(PAYMENT_METHODS[0].value)

function submit() {
  emit('submit', { customer_name: customerName.value, payment_method: paymentMethod.value })
}
function reset() { customerName.value = '' }
defineExpose({ reset })
</script>

<template>
  <div>
    <div class="field">
      <label for="cust">Nama pelanggan</label>
      <input id="cust" v-model="customerName" placeholder="Opsional" />
    </div>
    <div class="field">
      <label for="method">Metode pembayaran</label>
      <select id="method" v-model="paymentMethod">
        <option v-for="m in PAYMENT_METHODS" :key="m.value" :value="m.value">{{ m.label }}</option>
      </select>
    </div>
    <p class="total">Total: <strong>{{ rupiah(total) }}</strong></p>
    <p v-if="message" :class="['alert', message.ok ? 'alert-success' : 'alert-danger']" style="margin: 10px 0">
      {{ message.text }}
    </p>
    <BaseButton style="width: 100%" @click="submit">Simpan transaksi</BaseButton>
  </div>
</template>

<style scoped>
.total { font-size: 18px; margin: 8px 0; }
</style>
