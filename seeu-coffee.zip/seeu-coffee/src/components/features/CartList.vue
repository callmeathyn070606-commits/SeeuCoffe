<script setup>
import { rupiah } from '@/utils/format'
import BaseButton from '@/components/common/BaseButton.vue'

defineProps({ items: { type: Array, required: true } })
defineEmits(['change-qty', 'remove'])
</script>

<template>
  <ul class="cart">
    <li v-for="item in items" :key="item.product_id">
      <div>
        <strong>{{ item.name }}</strong>
        <p class="muted text-small">{{ rupiah(item.unit_price) }}</p>
      </div>
      <input
        class="qty"
        type="number"
        min="1"
        :value="item.qty"
        :aria-label="`Jumlah ${item.name}`"
        @change="$emit('change-qty', item.product_id, $event.target.value)"
      />
      <BaseButton variant="ghost" size="sm" @click="$emit('remove', item.product_id)">Hapus</BaseButton>
    </li>
    <li v-if="!items.length" class="muted">Pilih menu di sebelah kiri untuk mulai membuat pesanan.</li>
  </ul>
</template>

<style scoped>
.cart { list-style: none; padding: 0; display: grid; gap: 10px; }
.cart li { display: grid; grid-template-columns: 1fr 64px auto; gap: 8px; align-items: center; }
.qty { padding: 4px 6px; }
</style>
