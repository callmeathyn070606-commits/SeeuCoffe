<script setup>
import { reactive, watch } from 'vue'
import BaseButton from '@/components/common/BaseButton.vue'

const props = defineProps({
  product: { type: Object, default: null },
  categories: { type: Array, required: true },
  errors: { type: Object, default: () => ({}) }
})
const emit = defineEmits(['save', 'cancel'])

const emptyForm = () => ({ name: '', category_id: '', price: '', stock: 0, is_active: true })
const form = reactive(emptyForm())

watch(
  () => props.product,
  (p) => Object.assign(form, p ? { ...p } : emptyForm()),
  { immediate: true }
)
</script>

<template>
  <div class="modal-overlay" role="dialog" aria-modal="true">
    <form class="modal" @submit.prevent="emit('save', { ...form })" novalidate>
      <h2>{{ product ? 'Ubah produk' : 'Tambah produk baru' }}</h2>

      <div class="field" style="margin-top: 12px">
        <label for="p-name">Nama produk</label>
        <input id="p-name" v-model="form.name" />
        <span v-if="errors.name" class="error-text">{{ errors.name }}</span>
      </div>
      <div class="field">
        <label for="p-cat">Kategori</label>
        <select id="p-cat" v-model="form.category_id">
          <option value="" disabled>Pilih kategori</option>
          <option v-for="c in categories" :key="c.id" :value="c.id">{{ c.name }}</option>
        </select>
        <span v-if="errors.category_id" class="error-text">{{ errors.category_id }}</span>
      </div>
      <div class="field">
        <label for="p-price">Harga (Rp)</label>
        <input id="p-price" v-model="form.price" type="number" />
        <span v-if="errors.price" class="error-text">{{ errors.price }}</span>
      </div>
      <div class="field">
        <label for="p-stock">Stok</label>
        <input id="p-stock" v-model="form.stock" type="number" />
        <span v-if="errors.stock" class="error-text">{{ errors.stock }}</span>
      </div>
      <label class="text-small"><input v-model="form.is_active" type="checkbox" style="width: auto" /> Tampilkan di katalog</label>

      <div class="modal-actions">
        <BaseButton variant="ghost" @click="emit('cancel')">Batal</BaseButton>
        <BaseButton type="submit">Simpan</BaseButton>
      </div>
    </form>
  </div>
</template>
