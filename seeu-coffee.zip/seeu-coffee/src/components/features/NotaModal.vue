<script setup>
import { rupiah, formatDate } from '@/utils/format'
import BaseButton from '@/components/common/BaseButton.vue'

defineProps({ transaction: { type: Object, required: true } })
defineEmits(['close'])
const print = () => window.print()
</script>

<template>
  <Teleport to="body">
    <div class="modal-overlay">
      <div class="modal">
        <h2>Seeu Coffee</h2>
        <p class="muted text-small">{{ transaction.code }} &middot; {{ formatDate(transaction.created_at) }}</p>
        <p class="text-small">Pelanggan: {{ transaction.customer_name }}</p>
        <table style="margin-top: 10px">
          <tbody>
            <tr v-for="i in transaction.items" :key="i.product_id">
              <td>
                {{ i.name }} x{{ i.qty }}
                <div v-if="i.note" class="nota-note">Catatan: {{ i.note }}</div>
              </td>
              <td class="num">{{ rupiah(i.subtotal) }}</td>
            </tr>
            <tr>
              <td><strong>Total</strong></td>
              <td class="num"><strong>{{ rupiah(transaction.total) }}</strong></td>
            </tr>
          </tbody>
        </table>
        <div class="modal-actions no-print">
          <BaseButton variant="ghost" @click="$emit('close')">Tutup</BaseButton>
          <BaseButton @click="print">Cetak</BaseButton>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<style scoped>
.nota-note {
  margin-top: 0.25rem;
  color: #6eda98;
  font-size: 0.78rem;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
</style>
