import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { HOME_BY_ROLE, ROLES } from '@/constants'
import AuthLayout from '@/layouts/AuthLayout.vue'
import MainLayout from '@/layouts/MainLayout.vue'

const { OWNER, CASHIER } = ROLES

const routes = [
  {
    path: '/',
    redirect: () => {
      const auth = useAuthStore()
      return auth.isLoggedIn ? HOME_BY_ROLE[auth.role] : '/welcome'
    }
  },
  {
    path: '/welcome',
    component: () => import('@/views/WelcomeView.vue'),
    meta: { public: true }
  },
  {
    path: '/dashboard',
    component: AuthLayout,
    meta: { public: true },
    children: [{ path: '', name: 'dashboard-login', component: () => import('@/views/LoginView.vue') }]
  },
  { path: '/login', redirect: '/dashboard' },
  {
    path: '/',
    component: MainLayout,
    children: [
      { path: 'pemilik', component: () => import('@/views/owner/OwnerDashboard.vue'), meta: { roles: [OWNER] } },
      { path: 'pemilik/produk', component: () => import('@/views/owner/ProductManageView.vue'), meta: { roles: [OWNER] } },
      { path: 'pemilik/laporan', component: () => import('@/views/owner/ReportView.vue'), meta: { roles: [OWNER] } },
      { path: 'kasir', component: () => import('@/views/cashier/CashierDashboard.vue'), meta: { roles: [CASHIER] } },
      { path: 'kasir/pos', component: () => import('@/views/cashier/POSView.vue'), meta: { roles: [CASHIER] } },
      { path: 'kasir/keuangan', component: () => import('@/views/cashier/FinanceView.vue'), meta: { roles: [CASHIER] } },
      { path: 'kasir/pesanan', component: () => import('@/views/cashier/OrderListView.vue'), meta: { roles: [CASHIER, OWNER] } },
      { path: 'katalog', component: () => import('@/views/customer/CatalogView.vue'), meta: { public: true } },
      { path: 'status', component: () => import('@/views/customer/OrderStatusView.vue'), meta: { public: true } }
    ]
  },
  { path: '/:pathMatch(.*)*', redirect: '/' }
]

const router = createRouter({ history: createWebHistory(), routes })

router.beforeEach((to) => {
  const auth = useAuthStore()
  if (to.meta.public) {
    if (to.path === '/dashboard' && auth.isLoggedIn) return HOME_BY_ROLE[auth.role]
    return true
  }
  if (!auth.isLoggedIn) return '/login'
  const roles = to.meta.roles
  if (roles && !roles.includes(auth.role)) return HOME_BY_ROLE[auth.role]
  return true
})

export default router
