export function loadData(key) {
  try {
    const raw = localStorage.getItem(key)
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

export function saveData(key, value) {
  localStorage.setItem(key, JSON.stringify(value))
}

export function removeData(key) {
  localStorage.removeItem(key)
}
