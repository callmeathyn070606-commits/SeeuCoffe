import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import seedTransactions from '@/seed/transactions.json'
import { STORAGE_KEYS, PAYMENT_STATUS, ORDER_STATUS, DEFAULT_CUSTOMER_NAME, CODE_PREFIX } from '@/constants'
import { loadData, saveData } from '@/services/storage'
import { dateKey } from '@/utils/format'
import { useProductStore } from '@/stores/product'

export const useTransactionStore = defineStore('transaction', () => {
  const productStore = useProductStore()
  const transactions = ref([])
  const cart = ref([])

  const persist = () => saveData(STORAGE_KEYS.transactions, transactions.value)

  function init() {
    const saved = loadData(STORAGE_KEYS.transactions)
    if (saved) {
      transactions.value = saved
    } else {
      transactions.value = structuredClone(seedTransactions)
      persist()
    }
  }

  // ---- keranjang ----
  const cartTotal = computed(() => cart.value.reduce((sum, i) => sum + i.qty * i.unit_price, 0))

  function addToCart(product) {
    const existing = cart.value.find((i) => i.product_id === product.id)
    if (existing) {
      if (existing.qty < product.stock) existing.qty++
    } else if (product.stock > 0) {
      cart.value.push({ product_id: product.id, name: product.name, unit_price: product.price, qty: 1, note: '' })
    }
  }

  function changeQty(productId, qty) {
    const item = cart.value.find((i) => i.product_id === productId)
    const product = productStore.findById(productId)
    if (!item || !product) return
    item.qty = Math.max(1, Math.min(Number(qty) || 1, product.stock))
  }

  function removeFromCart(productId) {
    cart.value = cart.value.filter((i) => i.product_id !== productId)
  }

  function setItemNote(productId, note) {
    const item = cart.value.find((i) => i.product_id === productId)
    if (!item) return
    item.note = String(note).trim().slice(0, 200)
  }

  const clearCart = () => { cart.value = [] }

  // ---- transaksi ----
  function createTransaction({
    customer_name,
    payment_method,
    order_type = null,
    outlet_name = '',
    outlet_location = '',
    admin_fee = 0,
    payment_proof = ''
  }, userId) {
    if (!cart.value.length) return { ok: false, message: 'Keranjang masih kosong' }
    if (order_type && !['dine_in', 'take_away'].includes(order_type)) {
      return { ok: false, message: 'Jenis pesanan tidak valid' }
    }
    const fee = Number(admin_fee)
    if (!Number.isFinite(fee) || fee < 0) {
      return { ok: false, message: 'Biaya admin tidak valid' }
    }
    for (const item of cart.value) {
      const product = productStore.findById(item.product_id)
      if (!product || item.qty > product.stock) {
        return { ok: false, message: `Stok ${item.name} tidak mencukupi` }
      }
    }
    const id = transactions.value.reduce((max, t) => Math.max(max, t.id), 0) + 1
    const items = cart.value.map((i) => ({ ...i, subtotal: i.qty * i.unit_price }))
    const transaction = {
      id,
      code: `${CODE_PREFIX}${String(id).padStart(4, '0')}`,
      user_id: userId,
      customer_name: customer_name?.trim() || DEFAULT_CUSTOMER_NAME,
      order_type,
      outlet_name: outlet_name?.trim() || '',
      outlet_location: outlet_location?.trim() || '',
      payment_method,
      payment_status: PAYMENT_STATUS[0].value,
      order_status: ORDER_STATUS[0].value,
      admin_fee: fee,
      total: cartTotal.value + fee,
      payment_proof,
      created_at: new Date().toISOString(),
      items
    }
    transactions.value.unshift(transaction)
    productStore.reduceStock(items)
    clearCart()
    persist()
    return { ok: true, data: transaction }
  }

  function updateStatus(id, patch) {
    const tx = transactions.value.find((t) => t.id === id)
    if (!tx) return { ok: false, message: 'Transaksi tidak ditemukan' }
    const validPayment = PAYMENT_STATUS.some((s) => s.value === (patch.payment_status ?? tx.payment_status))
    const validOrder = ORDER_STATUS.some((s) => s.value === (patch.order_status ?? tx.order_status))
    if (!validPayment || !validOrder) return { ok: false, message: 'Status tidak valid' }
    Object.assign(tx, patch)
    persist()
    return { ok: true }
  }

  const findByCode = (code) =>
    transactions.value.find((t) => t.code.toLowerCase() === String(code).trim().toLowerCase())

  // ---- ringkasan ----
  const paidTransactions = computed(() => transactions.value.filter((t) => t.payment_status === 'lunas'))
  const totalRevenue = computed(() => paidTransactions.value.reduce((s, t) => s + t.total, 0))
  const unpaidCount = computed(() => transactions.value.filter((t) => t.payment_status !== 'lunas').length)
  const activeOrderCount = computed(() => transactions.value.filter((t) => t.order_status !== 'selesai').length)

  const revenueByDate = computed(() => {
    const map = {}
    paidTransactions.value.forEach((t) => {
      const key = dateKey(t.created_at)
      map[key] = (map[key] || 0) + t.total
    })
    return Object.entries(map)
      .map(([date, total]) => ({ date, total }))
      .sort((a, b) => b.date.localeCompare(a.date))
  })

  return {
    transactions, cart, cartTotal, init, addToCart, changeQty, removeFromCart, setItemNote, clearCart,
    createTransaction, updateStatus, findByCode,
    totalRevenue, unpaidCount, activeOrderCount, revenueByDate
  }
})
