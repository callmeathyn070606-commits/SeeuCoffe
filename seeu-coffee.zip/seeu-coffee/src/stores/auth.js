import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import seedUsers from '@/seed/users.json'
import { STORAGE_KEYS } from '@/constants'
import { loadData, saveData, removeData } from '@/services/storage'

export const useAuthStore = defineStore('auth', () => {
  const users = ref([])
  const session = ref(null)

  function init() {
    const saved = loadData(STORAGE_KEYS.users)
    if (saved) {
      users.value = saved
    } else {
      users.value = structuredClone(seedUsers)
      saveData(STORAGE_KEYS.users, users.value)
    }
    session.value = loadData(STORAGE_KEYS.session)
  }

  const isLoggedIn = computed(() => !!session.value)
  const user = computed(() => session.value)
  const role = computed(() => session.value?.role ?? null)

  function login(username, password) {
    if (!username.trim() || !password) {
      return false
    }
    const found = users.value.find((u) => u.username === username.trim() && u.password === password)
    if (!found) return false
    session.value = { id: found.id, name: found.name, username: found.username, role: found.role }
    saveData(STORAGE_KEYS.session, session.value)
    return true
  }

  function logout() {
    session.value = null
    removeData(STORAGE_KEYS.session)
  }

  return { users, session, user, isLoggedIn, role, init, login, logout }
})
