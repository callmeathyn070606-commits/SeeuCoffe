import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import seedProducts from '@/seed/products.json'
import seedCategories from '@/seed/categories.json'
import { STORAGE_KEYS, MAX_PRICE } from '@/constants'
import { loadData, saveData } from '@/services/storage'

export const useProductStore = defineStore('product', () => {
  const products = ref([])
  const categories = ref([])

  function init() {
    const savedProducts = loadData(STORAGE_KEYS.products)
    const savedCategories = loadData(STORAGE_KEYS.categories)
    const savedCategoryNames = new Map(
      (Array.isArray(savedCategories) ? savedCategories : [])
        .map((category) => [Number(category.id), String(category.name).trim().toLowerCase()])
    )
    const canonicalCategoryIds = Object.fromEntries(
      seedCategories.map((category) => [category.name.toLowerCase(), category.id])
    )
    const legacyCategoryNames = {
      signature: 'kopi',
      'base coffee': 'kopi',
      'non-coffee': 'non-kopi',
      mocktail: 'non-kopi',
      tea: 'non-kopi'
    }
    const legacyCategoryIds = {
      1: 'kopi',
      2: 'non-kopi',
      3: 'makanan',
      4: 'kopi',
      5: 'kopi',
      6: 'non-kopi',
      7: 'non-kopi',
      8: 'non-kopi'
    }

    if (savedProducts) {
      products.value = savedProducts.map((product) => {
        const categoryId = Number(product.category_id)
        const savedName = savedCategoryNames.get(categoryId)
        const categoryName = legacyCategoryNames[savedName] || savedName || legacyCategoryIds[categoryId] || 'non-kopi'
        return { ...product, category_id: canonicalCategoryIds[categoryName] || canonicalCategoryIds['non-kopi'] }
      })
      persist()
    } else {
      products.value = structuredClone(seedProducts)
      persist()
    }

    categories.value = structuredClone(seedCategories)
    saveData(STORAGE_KEYS.categories, categories.value)
  }

  const persist = () => saveData(STORAGE_KEYS.products, products.value)

  const activeProducts = computed(() => products.value.filter((p) => p.is_active))
  const findById = (id) => products.value.find((p) => p.id === id)
  const categoryName = (id) => categories.value.find((c) => c.id === id)?.name ?? '-'

  function validate(payload) {
    const errors = {}
    if (!payload.name || !payload.name.trim()) errors.name = 'Nama produk wajib diisi'
    if (!payload.category_id) errors.category_id = 'Kategori wajib dipilih'
    const price = Number(payload.price)
    if (!Number.isFinite(price) || price <= 0) errors.price = 'Harga harus lebih besar dari 0'
    else if (price > MAX_PRICE) errors.price = `Harga maksimal ${MAX_PRICE.toLocaleString('id-ID')}`
    const stock = Number(payload.stock)
    if (!Number.isInteger(stock) || stock < 0) errors.stock = 'Stok harus bilangan bulat 0 atau lebih'
    return errors
  }

  function normalize(payload) {
    return {
      category_id: Number(payload.category_id),
      name: payload.name.trim(),
      price: Number(payload.price),
      stock: Number(payload.stock),
      image: payload.image || '',
      is_active: payload.is_active !== undefined ? !!payload.is_active : true
    }
  }

  function addProduct(payload) {
    const errors = validate(payload)
    if (Object.keys(errors).length) return { ok: false, errors }
    const id = products.value.reduce((max, p) => Math.max(max, p.id), 0) + 1
    products.value.push({ id, ...normalize(payload) })
    persist()
    return { ok: true }
  }

  function updateProduct(id, payload) {
    const errors = validate(payload)
    if (Object.keys(errors).length) return { ok: false, errors }
    const index = products.value.findIndex((p) => p.id === id)
    if (index === -1) return { ok: false, errors: { name: 'Produk tidak ditemukan' } }
    products.value[index] = { id, ...normalize(payload) }
    persist()
    return { ok: true }
  }

  function removeProduct(id) {
    products.value = products.value.filter((p) => p.id !== id)
    persist()
  }

  function reduceStock(items) {
    items.forEach((item) => {
      const p = findById(item.product_id)
      if (p) p.stock = Math.max(0, p.stock - item.qty)
    })
    persist()
  }

  return {
    products, categories, activeProducts, init, findById, categoryName,
    validate, addProduct, updateProduct, removeProduct, reduceStock
  }
})
