export const STORAGE_KEYS = {
  users: 'seeu_users',
  categories: 'seeu_categories',
  products: 'seeu_products',
  transactions: 'seeu_transactions',
  expenses: 'seeu_expenses',
  session: 'seeu_session'
}

export const ROLES = { OWNER: 'pemilik', CASHIER: 'kasir', CUSTOMER: 'pelanggan' }

export const HOME_BY_ROLE = {
  pemilik: '/pemilik',
  kasir: '/kasir',
  pelanggan: '/katalog'
}

export const NAV_BY_ROLE = {
  pemilik: [
    { to: '/pemilik', label: 'Dashboard' },
    { to: '/pemilik/produk', label: 'Kelola Produk' },
    { to: '/pemilik/laporan', label: 'Laporan' },
    { to: '/katalog', label: 'Katalog' }
  ],
  kasir: [
    { to: '/kasir', label: 'Dashboard' },
    { to: '/kasir/pos', label: 'Kasir (POS)' },
    { to: '/kasir/pesanan', label: 'Daftar Pesanan' },
    { to: '/kasir/keuangan', label: 'Keuangan' }
  ],
  pelanggan: [
    { to: '/katalog', label: 'Katalog' },
    { to: '/status', label: 'Status Pesanan' }
  ]
}

export const PAYMENT_METHODS = [
  { value: 'tunai', label: 'Tunai' },
  { value: 'qris', label: 'QRIS' },
  { value: 'transfer', label: 'Transfer' }
]

export const ORDER_TYPES = [
  { value: 'dine_in', label: 'Dine In' },
  { value: 'take_away', label: 'Take Away' }
]

export const PAYMENT_STATUS = [
  { value: 'belum_dibayar', label: 'Belum dibayar', variant: 'warning' },
  { value: 'lunas', label: 'Lunas', variant: 'success' }
]

export const ORDER_STATUS = [
  { value: 'diproses', label: 'Diproses', variant: 'warning' },
  { value: 'siap', label: 'Siap diambil', variant: 'info' },
  { value: 'selesai', label: 'Selesai', variant: 'success' }
]

export const LOW_STOCK_LIMIT = 10
export const MAX_PRICE = 10000000
export const CUSTOMER_ADMIN_FEE = 0
export const DEFAULT_CUSTOMER_NAME = 'Pelanggan umum'
export const CODE_PREFIX = 'SEEU-'
