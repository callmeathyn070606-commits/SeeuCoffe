import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import router from './router'
import { useAuthStore } from '@/stores/auth'
import { useProductStore } from '@/stores/product'
import { useTransactionStore } from '@/stores/transaction'
import './assets/main.css'

const app = createApp(App)
const pinia = createPinia()
app.use(pinia)

// Muat seed ke localStorage (jika kosong) sebelum router berjalan
useAuthStore().init()
useProductStore().init()
useTransactionStore().init()

app.use(router)
app.mount('#app')
