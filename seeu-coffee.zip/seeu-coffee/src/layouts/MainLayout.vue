<script setup>
import AppNavbar from '@/components/common/AppNavbar.vue'
import AppFooter from '@/components/common/AppFooter.vue'
</script>

<template>
  <div>
    <AppNavbar class="no-print" />
    <main class="main-content">
      <router-view />
    </main>
    <AppFooter class="no-print" />
  </div>
</template>
