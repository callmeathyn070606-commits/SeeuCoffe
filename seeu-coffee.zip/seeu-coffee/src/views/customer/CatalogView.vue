<template>
  <section>
    <div class="catalog-header">
      <h2>Katalog Menu</h2>
      <p class="page-subtitle">Temukan minuman dan makanan favorit Anda</p>
    </div>

    <div class="toolbar">
      <div class="search-box">
        <span class="search-icon">🔍</span>
        <input v-model="search" placeholder="Cari menu..." />
      </div>
    </div>

    <div class="customer-order-layout">
      <div class="menu-section">
        <div class="category-tags" v-if="categories.length">
          <button
            v-for="c in [{ id: '', name: 'Semua' }, ...categories]"
            :key="c.id"
            :class="['tag', { active: catFilter === c.id }]"
            @click="catFilter = c.id"
          >
            {{ c.name }}
          </button>
        </div>

        <div class="product-grid catalog">
          <div v-for="p in filtered" :key="p.id" class="product-card">
            <div class="card-category">{{ getCatName(p.category_id) }}</div>
            <div class="catalog-image-frame">
              <img v-if="p.image" class="catalog-product-image" :src="p.image" :alt="p.name" />
              <div v-else class="catalog-image-placeholder" aria-hidden="true">☕</div>
            </div>
            <div class="card-body">
              <p class="product-id">ID Menu #{{ p.id }}</p>
              <h3>{{ p.name }}</h3>
              <p class="price">{{ rupiah(p.price) }}</p>
              <p class="stock" :class="{ low: p.stock <= LOW_STOCK_LIMIT }">
                <span v-if="p.stock > LOW_STOCK_LIMIT">✓ Tersedia</span>
                <span v-else-if="p.stock > 0">⚠ Stok terbatas ({{ p.stock }})</span>
                <span v-else>✕ Habis</span>
              </p>
              <button class="btn-primary add-to-cart" :disabled="p.stock <= 0" @click="addToCart(p)">
                {{ p.stock > 0 ? 'Tambah ke Keranjang' : 'Stok Habis' }}
              </button>
            </div>
          </div>
        </div>
        <p v-if="filtered.length === 0" class="empty">Produk tidak ditemukan.</p>
      </div>

      <aside class="customer-cart">
        <h3>Keranjang <span class="cart-count">{{ tx.cart.length }}</span></h3>
        <p v-if="tx.cart.length === 0" class="cart-empty">Pilih menu untuk mulai memesan.</p>

        <div v-for="item in tx.cart" :key="item.product_id" class="cart-item">
          <div class="cart-item-info">
            <strong>{{ item.name }}</strong>
            <span>{{ rupiah(item.unit_price) }}</span>
          </div>
          <div class="cart-item-controls">
            <button type="button" :aria-label="`Kurangi ${item.name}`" @click="changeQuantity(item, -1)">−</button>
            <span>{{ item.qty }}</span>
            <button type="button" :aria-label="`Tambah ${item.name}`" @click="changeQuantity(item, 1)">+</button>
            <button type="button" class="remove-item" :aria-label="`Hapus ${item.name}`" @click="tx.removeFromCart(item.product_id)">×</button>
          </div>
          <label class="cart-item-note">
            <span>Catatan</span>
            <textarea
              :value="item.note"
              maxlength="200"
              rows="2"
              :aria-label="`Catatan untuk ${item.name}`"
              placeholder="Contoh: kurang manis"
              @input="tx.setItemNote(item.product_id, $event.target.value)"
            ></textarea>
          </label>
        </div>

        <form v-if="tx.cart.length" class="checkout-form" @submit.prevent="submitOrder">
          <label for="customer-name">Nama pemesan</label>
          <input id="customer-name" v-model="customerName" required maxlength="80" placeholder="Nama Anda" />

          <fieldset>
            <legend>Jenis pesanan</legend>
            <label v-for="type in ORDER_TYPES" :key="type.value" class="payment-option">
              <input v-model="orderType" type="radio" name="order-type" :value="type.value" required />
              <span>{{ type.label }}</span>
            </label>
          </fieldset>

          <fieldset>
            <legend>Metode pembayaran</legend>
            <label v-for="method in customerPaymentMethods" :key="method.value" class="payment-option">
              <input v-model="paymentMethod" type="radio" name="payment-method" :value="method.value" />
              <span>{{ method.label }}</span>
            </label>
          </fieldset>

          <div v-if="paymentMethod === 'qris'" class="proof-field">
            <label for="payment-proof">Bukti pembayaran QRIS</label>
            <input
              id="payment-proof"
              ref="proofInput"
              type="file"
              accept="image/png,image/jpeg,image/webp"
              required
              @change="handleProofChange"
            />
            <small>Unggah gambar bukti bayar (maks. 5 MB; disimpan lokal di browser ini).</small>
            <div v-if="paymentProof" class="proof-preview">
              <img :src="paymentProof" alt="Pratinjau bukti pembayaran" />
              <button type="button" class="remove-proof" @click="removeProof">Hapus bukti</button>
            </div>
          </div>

          <div class="cart-total">
            <div class="price-breakdown">
              <span>Subtotal produk</span>
              <strong>{{ rupiah(tx.cartTotal) }}</strong>
              <span>Biaya admin</span>
              <strong>{{ rupiah(CUSTOMER_ADMIN_FEE) }}</strong>
              <small v-if="CUSTOMER_ADMIN_FEE === 0" class="fee-note">Biaya admin belum dikonfigurasi.</small>
            </div>
            <div class="total-row">
              <span>Total pembayaran</span>
              <strong>{{ rupiah(orderTotal) }}</strong>
            </div>
          </div>
          <p v-if="checkoutError" class="checkout-error" role="alert">{{ checkoutError }}</p>
          <button class="btn-primary checkout-button" type="submit">Buat Pesanan</button>
          <small class="payment-note">
            {{ paymentMethod === 'qris'
              ? 'Prototipe lokal: kasir akan memeriksa bukti QRIS secara manual. Pembayaran tidak diproses otomatis.'
              : 'Pembayaran tunai dilakukan saat pickup di outlet.' }}
          </small>
        </form>
      </aside>
    </div>

    <Teleport to="body">
      <div v-if="lastOrder" class="order-success-overlay" @click.self="lastOrder = null">
        <div class="order-success" role="dialog" aria-modal="true" aria-labelledby="order-success-title">
          <span class="order-success-icon" aria-hidden="true">✓</span>
          <h3 id="order-success-title">Pesanan berhasil dibuat!</h3>
          <p>Kode pesanan: <strong>{{ lastOrder.code }}</strong></p>
          <p>Biaya admin: <strong>{{ rupiah(lastOrder.admin_fee || 0) }}</strong></p>
          <p>Total: <strong>{{ rupiah(lastOrder.total) }}</strong></p>
          <p>Jenis pesanan: <strong>{{ orderTypeLabel(lastOrder.order_type) }}</strong></p>
          <div v-if="lastOrder.items.some(item => item.note)" class="order-notes">
            <strong>Catatan pesanan:</strong>
            <p v-for="item in lastOrder.items.filter(item => item.note)" :key="item.product_id">
              {{ item.name }}: {{ item.note }}
            </p>
          </div>
          <p class="payment-instruction">
            {{ lastOrder.payment_method === 'qris'
              ? 'Tunjukkan kode pesanan ini kepada kasir untuk menyelesaikan pembayaran QRIS.'
              : 'Silakan bayar tunai kepada kasir dengan menyebutkan kode pesanan ini.' }}
          </p>
          <button class="btn-primary order-success-close" type="button" @click="lastOrder = null">Kembali ke Katalog</button>
        </div>
      </div>
    </Teleport>
  </section>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useProductStore } from '@/stores/product'
import { useTransactionStore } from '@/stores/transaction'
import { useAuthStore } from '@/stores/auth'
import { rupiah } from '@/utils/format'
import { CUSTOMER_ADMIN_FEE, LOW_STOCK_LIMIT, ORDER_TYPES, PAYMENT_METHODS } from '@/constants'

const ps = useProductStore()
const tx = useTransactionStore()
const auth = useAuthStore()
const search = ref('')
const catFilter = ref('')
const customerName = ref(auth.user?.name || '')
const orderType = ref('take_away')
const customerPaymentMethods = PAYMENT_METHODS.filter(method => ['tunai', 'qris'].includes(method.value))
const paymentMethod = ref(customerPaymentMethods[0].value)
const paymentProof = ref('')
const proofInput = ref(null)
const checkoutError = ref('')
const lastOrder = ref(null)

const categories = computed(() => ps.categories)
const orderTotal = computed(() => tx.cartTotal + CUSTOMER_ADMIN_FEE)
const filtered = computed(() => {
  let list = ps.activeProducts
  if (catFilter.value !== '') list = list.filter(p => String(p.category_id) === String(catFilter.value))
  if (search.value) {
    const q = search.value.toLowerCase()
    list = list.filter(p => p.name.toLowerCase().includes(q))
  }
  return list
})

function getCatName (id) {
  return ps.categories.find(c => c.id === id)?.name || '-'
}

function orderTypeLabel (value) {
  return ORDER_TYPES.find(type => type.value === value)?.label || 'Jenis pesanan'
}

function addToCart (product) {
  checkoutError.value = ''
  tx.addToCart(product)
}

function changeQuantity (item, delta) {
  const product = ps.findById(item.product_id)
  if (!product) {
    checkoutError.value = `Menu ${item.name} tidak ditemukan.`
    return
  }
  const quantity = item.qty + delta
  if (quantity <= 0) tx.removeFromCart(item.product_id)
  else tx.changeQty(item.product_id, quantity)
  checkoutError.value = ''
}

function handleProofChange (event) {
  const file = event.target.files?.[0]
  if (!file) return

  if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) {
    checkoutError.value = 'Bukti pembayaran harus berupa gambar PNG, JPG, atau WEBP.'
    event.target.value = ''
    return
  }
  if (file.size > 5 * 1024 * 1024) {
    checkoutError.value = 'Ukuran bukti pembayaran maksimal 5 MB.'
    event.target.value = ''
    return
  }

  const reader = new FileReader()
  reader.onload = () => {
    if (typeof reader.result !== 'string') {
      checkoutError.value = 'Bukti pembayaran gagal dibaca.'
      event.target.value = ''
      return
    }

    const image = new Image()
    image.onload = () => {
      const canvas = document.createElement('canvas')
      const context = canvas.getContext('2d')
      if (!context) {
        checkoutError.value = 'Browser tidak dapat memproses bukti pembayaran.'
        event.target.value = ''
        return
      }

      const scale = Math.min(1, 1600 / Math.max(image.width, image.height))
      canvas.width = Math.max(1, Math.round(image.width * scale))
      canvas.height = Math.max(1, Math.round(image.height * scale))
      context.drawImage(image, 0, 0, canvas.width, canvas.height)

      for (const quality of [0.86, 0.78, 0.7, 0.62]) {
        const compressed = canvas.toDataURL('image/webp', quality)
        const size = Math.ceil((compressed.length - compressed.indexOf(',') - 1) * 0.75)
        if (size <= 300 * 1024) {
          paymentProof.value = compressed
          checkoutError.value = ''
          return
        }
      }

      checkoutError.value = 'Bukti terlalu besar untuk disimpan. Pilih gambar yang lebih kecil.'
      event.target.value = ''
    }
    image.onerror = () => {
      checkoutError.value = 'File bukti pembayaran tidak dapat dibuka.'
      event.target.value = ''
    }
    image.src = reader.result
  }
  reader.onerror = () => {
    checkoutError.value = 'Bukti pembayaran gagal dibaca.'
    event.target.value = ''
  }
  reader.readAsDataURL(file)
}

function removeProof () {
  paymentProof.value = ''
  if (proofInput.value) proofInput.value.value = ''
}

function submitOrder () {
  checkoutError.value = ''
  if (paymentMethod.value === 'qris' && !paymentProof.value) {
    checkoutError.value = 'Unggah bukti pembayaran QRIS terlebih dahulu.'
    return
  }
  const result = tx.createTransaction({
    customer_name: customerName.value,
    payment_method: paymentMethod.value,
    order_type: orderType.value,
    admin_fee: CUSTOMER_ADMIN_FEE,
    payment_proof: paymentMethod.value === 'qris' ? paymentProof.value : ''
  }, auth.user?.id)

  if (!result.ok) {
    checkoutError.value = result.message
    return
  }
  if (!auth.isLoggedIn) {
    localStorage.setItem('seeu_last_order_code', result.data.code)
  }
  lastOrder.value = result.data
}
</script>

<style scoped>
.catalog-header {
  margin-bottom: 1.5rem;
}

.page-subtitle {
  color: rgba(255,255,255,0.5);
  font-size: 0.9rem;
  margin-top: 0.75rem;
}

.search-box {
  position: relative;
  flex: 1;
  max-width: 320px;
}

.search-icon {
  position: absolute;
  left: 0.75rem;
  top: 50%;
  transform: translateY(-50%);
  font-size: 0.85rem;
  opacity: 0.5;
}

.search-box input {
  padding-left: 2.25rem;
}

.category-tags {
  display: flex;
  gap: 0.4rem;
  flex-wrap: wrap;
  margin-bottom: 1.25rem;
}

.tag {
  padding: 0.4rem 0.9rem;
  border-radius: 999px;
  font-size: 0.8rem;
  font-weight: 500;
  border: 1px solid rgba(255,255,255,0.1);
  background: rgba(255,255,255,0.03);
  color: rgba(255,255,255,0.6);
  cursor: pointer;
  transition: all 0.2s ease;
}

.tag:hover {
  background: rgba(46,204,113,0.1);
  border-color: rgba(46,204,113,0.2);
  color: rgba(255,255,255,0.8);
}

.tag.active {
  background: linear-gradient(135deg, #14612a, #1a7a35);
  border-color: #22994a;
  color: #fff;
  box-shadow: 0 2px 10px rgba(46,204,113,0.2);
}

.card-category {
  padding: 0.4rem 0.75rem;
  font-size: 0.7rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: rgba(255,255,255,0.4);
  background: rgba(255,255,255,0.03);
  border-bottom: 1px solid rgba(255,255,255,0.05);
}

.catalog-image-frame {
  width: min(100%, 180px);
  aspect-ratio: 9 / 16;
  height: auto;
  margin: 0 auto;
  display: grid;
  place-items: center;
  overflow: hidden;
  background: radial-gradient(ellipse at center, rgba(121, 164, 125, 0.12), transparent 72%);
}

.catalog-product-image {
  width: 100%;
  height: 100%;
  padding: 0.65rem;
  object-fit: contain;
  filter: drop-shadow(0 10px 14px rgba(0, 0, 0, 0.24));
  -webkit-mask-image: radial-gradient(ellipse 100% 100% at center, #000 70%, rgba(0, 0, 0, 0.88) 88%, transparent 100%);
  mask-image: radial-gradient(ellipse 100% 100% at center, #000 70%, rgba(0, 0, 0, 0.88) 88%, transparent 100%);
}

.catalog-image-placeholder {
  width: 100%;
  height: 100%;
  display: grid;
  place-items: center;
  color: rgba(191, 208, 193, 0.45);
  font-size: 2rem;
}

.catalog .product-card .card-body {
  text-align: center;
  padding: 1.25rem 1rem 1.5rem;
}

.catalog .product-card .card-body h3 {
  font-size: 1.05rem;
}

.catalog .product-card .price {
  margin-top: 0.5rem;
  font-size: 1.1rem;
}

.catalog .product-card .stock {
  margin-top: 0.4rem;
  font-size: 0.78rem;
}

.product-id {
  margin-bottom: 0.2rem;
  color: var(--text-muted);
  font-size: 0.68rem;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}

.customer-order-layout {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 320px;
  align-items: stretch;
  height: calc(100vh - 20.5rem);
  height: calc(100dvh - 20.5rem);
  min-height: 18rem;
  gap: 1.25rem;
}

.menu-section {
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior-y: contain;
}

.menu-section .category-tags {
  margin-top: 0.25rem;
}

.catalog .product-card .add-to-cart {
  margin-top: 0.9rem;
  padding: 0.6rem 0.75rem;
  font-size: 0.82rem;
}

.add-to-cart:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

.customer-cart {
  min-height: 0;
  height: 100%;
  overflow-y: auto;
  overscroll-behavior-y: contain;
  padding: 1.25rem;
  border: 1px solid var(--border-glass);
  border-radius: var(--radius-lg);
  background: rgba(14, 48, 31, 0.92);
  box-shadow: 0 16px 38px rgba(0, 0, 0, 0.24);
}

.customer-cart h3 {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.8rem;
}

.cart-count {
  min-width: 1.5rem;
  height: 1.5rem;
  display: inline-grid;
  place-items: center;
  border-radius: 999px;
  background: rgba(121, 201, 154, 0.18);
  color: #b7e5c4;
  font-size: 0.75rem;
}

.cart-empty {
  padding: 1.1rem 0;
  color: var(--text-muted);
  font-size: 0.88rem;
}

.cart-item {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  align-items: start;
  gap: 0.5rem 0.75rem;
  padding: 0.7rem 0;
  border-bottom: 1px solid var(--border-glass);
}

.cart-item-info {
  display: grid;
  gap: 0.2rem;
  min-width: 0;
}

.cart-item-info strong {
  font-size: 0.86rem;
  overflow-wrap: anywhere;
}

.cart-item-info span {
  color: var(--text-secondary);
  font-size: 0.78rem;
}

.cart-item-controls {
  display: flex;
  align-items: center;
  gap: 0.35rem;
}

.cart-item-controls button {
  width: 1.7rem;
  height: 1.7rem;
  border: 1px solid var(--border-glass);
  border-radius: 0.4rem;
  background: rgba(255,255,255,0.06);
  color: var(--text-primary);
}

.cart-item-controls .remove-item {
  border: 0;
  background: transparent;
  color: #f19b8e;
  font-size: 1.2rem;
}

.cart-item-controls span {
  min-width: 1rem;
  text-align: center;
  font-size: 0.85rem;
}

.cart-item-note {
  grid-column: 1 / -1;
  display: grid;
  gap: 0.35rem;
  color: var(--text-muted);
  font-size: 0.75rem;
}

.cart-item-note textarea {
  width: 100%;
  min-height: 3.25rem;
  resize: vertical;
  padding: 0.55rem 0.65rem;
  border: 1px solid var(--border-glass);
  border-radius: 0.55rem;
  background: rgba(255,255,255,0.04);
  color: var(--text-primary);
  font-size: 0.82rem;
}

.checkout-form {
  margin-top: 0.9rem;
}

.proof-field {
  margin-top: 0.8rem;
}

.proof-field input[type="file"] {
  padding: 0.45rem;
  font-size: 0.78rem;
}

.proof-field small {
  display: block;
  margin-top: 0.35rem;
  color: var(--text-muted);
  line-height: 1.45;
}

.proof-preview {
  display: flex;
  align-items: flex-start;
  gap: 0.65rem;
  margin-top: 0.65rem;
}

.proof-preview img {
  width: 76px;
  height: 76px;
  object-fit: cover;
  border: 1px solid var(--border-glass);
  border-radius: var(--radius-sm);
}

.remove-proof {
  border: 0;
  background: transparent;
  color: #efaa9d;
  font-size: 0.78rem;
}

.checkout-form fieldset {
  margin-top: 0.9rem;
  padding: 0.65rem 0.75rem;
  border: 1px solid var(--border-glass);
  border-radius: var(--radius-md);
}

.checkout-form legend {
  padding: 0 0.25rem;
  color: var(--text-secondary);
  font-size: 0.8rem;
}

.payment-option {
  display: flex;
  align-items: center;
  gap: 0.55rem;
  margin: 0.35rem 0;
  cursor: pointer;
}

.payment-option input {
  width: auto;
  accent-color: var(--accent);
}

.payment-option span {
  font-size: 0.86rem;
}

.cart-total {
  margin: 1rem 0;
  font-size: 0.92rem;
}

.price-breakdown {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 0.35rem 0.75rem;
  color: var(--text-secondary);
  font-size: 0.82rem;
}

.price-breakdown strong {
  text-align: right;
  color: var(--text-primary);
}

.fee-note {
  grid-column: 1 / -1;
  color: var(--text-muted);
  font-size: 0.72rem;
}

.total-row {
  display: flex;
  justify-content: space-between;
  gap: 0.5rem;
  margin-top: 0.75rem;
  padding-top: 0.75rem;
  border-top: 1px solid var(--border-glass);
}

.total-row strong {
  color: #b7e5c4;
}

.checkout-button {
  width: 100%;
}

.payment-note {
  display: block;
  margin-top: 0.55rem;
  color: var(--text-muted);
  line-height: 1.45;
}

.checkout-error {
  margin: 0.5rem 0;
  color: #ffaaa0;
  font-size: 0.84rem;
}

.order-success-overlay {
  position: fixed;
  inset: 0;
  z-index: 300;
  display: grid;
  place-items: center;
  padding: 1rem;
  background: rgba(2, 13, 8, 0.76);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  animation: fadeIn 0.2s ease;
}

.order-success {
  width: min(100%, 460px);
  max-height: calc(100dvh - 2rem);
  overflow-y: auto;
  padding: clamp(1.5rem, 5vw, 2.25rem);
  border: 1px solid rgba(215, 190, 139, 0.25);
  border-radius: var(--radius-xl);
  background:
    radial-gradient(ellipse at 50% 0, rgba(116, 159, 92, 0.18), transparent 60%),
    #0d301f;
  box-shadow: 0 28px 80px rgba(0, 0, 0, 0.48);
  text-align: center;
  animation: scaleIn 0.25s ease;
}

.order-success h3 {
  margin-bottom: 0.8rem;
  color: #e3c991;
}

.order-success p {
  margin-top: 0.55rem;
  font-size: 0.95rem;
}

.order-success-icon {
  width: 3rem;
  height: 3rem;
  display: grid;
  place-items: center;
  margin: 0 auto 1rem;
  border: 1px solid rgba(130, 189, 139, 0.35);
  border-radius: 50%;
  background: rgba(130, 189, 139, 0.12);
  color: #a0d4a0;
  font-size: 1.5rem;
}

.order-notes {
  margin-top: 0.75rem;
  padding: 0.75rem;
  border: 1px solid var(--border-glass);
  border-radius: 0.65rem;
  background: rgba(255,255,255,0.03);
  text-align: left;
  font-size: 0.85rem;
}

.order-notes p {
  margin-top: 0.35rem;
  color: var(--text-secondary);
  font-size: 0.82rem;
}

.payment-instruction {
  color: var(--text-secondary);
  line-height: 1.65;
}

.order-success-close {
  width: 100%;
  margin-top: 1.25rem;
}

@media (max-width: 900px) {
  .customer-order-layout {
    grid-template-columns: 1fr;
    height: auto;
  }

  .menu-section,
  .customer-cart {
    height: 70vh;
    height: 70dvh;
    max-height: 70vh;
    max-height: 70dvh;
  }

  .customer-cart {
    position: static;
  }
}
</style>
