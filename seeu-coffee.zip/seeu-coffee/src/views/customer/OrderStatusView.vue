<template>
  <section>
    <h2>Status Pesanan</h2>
    <p class="page-subtitle">Pantau perkembangan pesanan Anda</p>

    <p v-if="customerOrders.length === 0" class="orders-empty">
      Anda belum memiliki pesanan. <router-link to="/katalog">Lihat katalog menu</router-link>
    </p>

    <div v-else class="customer-orders">
      <article v-for="order in customerOrders" :key="order.id" class="order-detail-card">
        <div class="order-header">
          <div>
            <span class="code-badge-lg">{{ order.code }}</span>
            <span class="order-date">{{ fmtDate(order.created_at) }}</span>
          </div>
          <div class="order-statuses">
            <span :class="'badge ' + badgeClass(order.order_status)">{{ statusLabel(order.order_status) }}</span>
            <span :class="'badge ' + payBadge(order.payment_status)">{{ payLabel(order.payment_status) }}</span>
          </div>
        </div>

        <div class="order-info">
          <p v-if="order.order_type"><strong>Jenis pesanan:</strong> {{ orderTypeLabel(order.order_type) }}</p>
          <p><strong>Biaya admin:</strong> {{ rupiah(order.admin_fee || 0) }}{{ order.admin_fee ? '' : ' (belum dikonfigurasi)' }}</p>
          <p v-if="order.payment_proof">
            <strong>Bukti pembayaran:</strong>
            <a :href="order.payment_proof" :download="`bukti-${order.code}.webp`">Unduh bukti</a>
          </p>
        </div>

        <table>
          <thead><tr><th>Produk</th><th>Qty</th><th>Harga</th><th>Subtotal</th></tr></thead>
          <tbody>
            <tr v-for="(item, i) in order.items" :key="i">
              <td>{{ item.name }}</td><td>{{ item.qty }}</td><td>{{ rupiah(item.unit_price) }}</td><td>{{ rupiah(item.unit_price * item.qty) }}</td>
            </tr>
          </tbody>
        </table>
        <p class="total">Total: {{ rupiah(order.total) }}</p>
        <p v-if="order.order_status === 'siap'" class="pickup-notice">
          {{ order.order_type === 'dine_in' ? 'Pesanan dine-in siap disajikan.' : 'Pesanan siap diambil.' }}
        </p>
        <p v-else-if="order.order_status === 'diproses'" class="pickup-notice">
          Pesanan sedang disiapkan. Status akan berubah setelah pesanan siap.
        </p>
        <p v-else-if="order.order_status === 'selesai'" class="pickup-notice">
          Pesanan selesai. Terima kasih telah memesan di SeeU Coffee.
        </p>
      </article>
    </div>
  </section>
</template>

<script setup>
import { computed } from 'vue'
import { useTransactionStore } from '@/stores/transaction'
import { useAuthStore } from '@/stores/auth'
import { rupiah, formatDate } from '@/utils/format'
import { ORDER_STATUS, ORDER_TYPES, PAYMENT_STATUS } from '@/constants'

const tx = useTransactionStore()
const auth = useAuthStore()
const customerOrders = computed(() => {
  const orders = auth.isLoggedIn
    ? tx.transactions.filter(order => String(order.user_id) === String(auth.user?.id))
    : tx.transactions.filter(order => order.code === localStorage.getItem('seeu_last_order_code'))

  return orders.sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
})

function badgeClass (s) { return ORDER_STATUS.find(x => x.value === s)?.variant || '' }
function statusLabel (s) { return ORDER_STATUS.find(x => x.value === s)?.label || s }
function orderTypeLabel (s) { return ORDER_TYPES.find(x => x.value === s)?.label || '—' }
function payBadge (s) { return PAYMENT_STATUS.find(x => x.value === s)?.variant || '' }
function payLabel (s) { return PAYMENT_STATUS.find(x => x.value === s)?.label || s }
function fmtDate (iso) { return formatDate(iso) }
</script>

<style scoped>
.page-subtitle {
  color: rgba(255,255,255,0.5);
  font-size: 0.9rem;
  margin-top: 0.75rem;
  margin-bottom: 1.5rem;
}

.customer-orders {
  display: grid;
  gap: 1rem;
}

.orders-empty {
  padding: 1.5rem;
  border: 1px solid var(--border-glass);
  border-radius: var(--radius-md);
  background: var(--bg-glass);
  color: var(--text-secondary);
  text-align: center;
}

.orders-empty a {
  color: #a0d4a0;
  font-weight: 600;
}

.order-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 1rem;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.code-badge-lg {
  font-family: 'Courier New', monospace;
  font-size: 1.1rem;
  font-weight: 700;
  padding: 0.3rem 0.75rem;
  background: rgba(46,204,113,0.1);
  border: 1px solid rgba(46,204,113,0.25);
  border-radius: 0.4rem;
  color: #6eda98;
}

.order-date {
  display: block;
  font-size: 0.8rem;
  color: rgba(255,255,255,0.4);
  margin-top: 0.4rem;
}

.order-statuses {
  display: flex;
  gap: 0.4rem;
}

.order-info {
  margin-bottom: 1rem;
}

.order-info p {
  font-size: 0.9rem;
}

.order-info strong {
  color: rgba(168,235,196,0.8);
}

.pickup-notice {
  margin-top: 1rem;
  padding: 0.85rem 1rem;
  border: 1px solid rgba(130, 189, 139, 0.24);
  border-radius: var(--radius-md);
  background: rgba(130, 189, 139, 0.08);
  color: #d7e8d2;
}

</style>
