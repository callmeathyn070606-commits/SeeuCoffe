<script setup>
import OwnerDashboard from './OwnerDashboard.vue'
</script>

<template>
  <OwnerDashboard />
</template>
