<template>
  <section>
    <div class="dashboard-header">
      <div>
        <h2>Dashboard Pemilik</h2>
        <p class="dashboard-subtitle">Selamat datang kembali! Berikut ringkasan bisnis Anda.</p>
      </div>
    </div>

    <div class="stat-grid">
      <div class="stat-card">
        <div class="stat-icon">📦</div>
        <span class="stat-label">Total Produk</span>
        <span class="stat-value">{{ productStore.products.length }}</span>
      </div>
      <div class="stat-card">
        <div class="stat-icon">⚠️</div>
        <span class="stat-label">Stok Rendah</span>
        <span class="stat-value" :class="{ warn: lowStock > 0 }">{{ lowStock }}</span>
      </div>
      <div class="stat-card">
        <div class="stat-icon">🧾</div>
        <span class="stat-label">Total Transaksi</span>
        <span class="stat-value">{{ txStore.transactions.length }}</span>
      </div>
      <div class="stat-card">
        <div class="stat-icon">💰</div>
        <span class="stat-label">Total Pendapatan</span>
        <span class="stat-value highlight">{{ rupiah(txStore.totalRevenue) }}</span>
      </div>
    </div>

    <div class="quick-info" v-if="lowStockProducts.length">
      <h3>⚠️ Produk Stok Rendah</h3>
      <div class="low-stock-list">
        <div v-for="p in lowStockProducts" :key="p.id" class="low-stock-item">
          <span class="low-stock-name">{{ p.name }}</span>
          <span class="low-stock-count">{{ p.stock }} tersisa</span>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
import { computed } from 'vue'
import { useProductStore } from '@/stores/product'
import { useTransactionStore } from '@/stores/transaction'
import { rupiah } from '@/utils/format'
import { LOW_STOCK_LIMIT } from '@/constants'

const productStore = useProductStore()
const txStore = useTransactionStore()

const lowStock = computed(() => productStore.products.filter(p => p.stock <= LOW_STOCK_LIMIT).length)
const lowStockProducts = computed(() => productStore.products.filter(p => p.stock <= LOW_STOCK_LIMIT))

const thisMonth = new Date().toISOString().slice(0, 7)
const monthRevenue = computed(() =>
  txStore.transactions
    .filter(t => t.created_at.startsWith(thisMonth) && t.payment_status === 'lunas')
    .reduce((s, t) => s + t.total, 0)
)
</script>

<style scoped>
.dashboard-header {
  margin-bottom: 2rem;
}

.dashboard-subtitle {
  color: rgba(255,255,255,0.5);
  font-size: 0.9rem;
  margin-top: 0.75rem;
}

.stat-icon {
  font-size: 1.75rem;
  margin-bottom: 0.5rem;
}

.stat-value.highlight {
  color: #2ecc71;
}

.quick-info {
  margin-top: 2rem;
  background: rgba(15, 40, 15, 0.45);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  padding: 1.5rem;
  border-radius: 0.75rem;
  border: 1px solid rgba(255,193,7,0.15);
}

.quick-info h3 {
  margin-bottom: 1rem;
  font-size: 1rem;
  color: #ffc107;
}

.low-stock-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 0.5rem;
}

.low-stock-item {
  display: flex;
  justify-content: space-between;
  padding: 0.5rem 0.75rem;
  background: rgba(255,255,255,0.03);
  border-radius: 0.5rem;
  border: 1px solid rgba(255,255,255,0.05);
  font-size: 0.85rem;
}

.low-stock-name {
  color: rgba(255,255,255,0.8);
}

.low-stock-count {
  color: #ff6b6b;
  font-weight: 600;
}
</style>
