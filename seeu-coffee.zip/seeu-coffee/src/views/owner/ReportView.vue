<template>
  <section>
    <h2>Laporan Penjualan</h2>
    <p class="page-subtitle">Lihat laporan transaksi berdasarkan periode</p>

    <div class="toolbar">
      <div class="date-group">
        <label>Dari</label>
        <input type="date" v-model="from" />
      </div>
      <div class="date-group">
        <label>Sampai</label>
        <input type="date" v-model="to" />
      </div>
    </div>

    <div class="stat-grid" style="margin-top:1rem">
      <div class="stat-card">
        <div class="stat-icon">🧾</div>
        <span class="stat-label">Jumlah Transaksi</span>
        <span class="stat-value">{{ filtered.length }}</span>
      </div>
      <div class="stat-card">
        <div class="stat-icon">💰</div>
        <span class="stat-label">Total Pendapatan</span>
        <span class="stat-value highlight">{{ rupiah(totalRev) }}</span>
      </div>
    </div>

    <table v-if="filtered.length">
      <thead><tr><th>Kode</th><th>Tanggal</th><th>Pelanggan</th><th>Total</th><th>Bayar</th><th>Status</th></tr></thead>
      <tbody>
        <tr v-for="t in filtered" :key="t.id">
          <td><span class="code-badge">{{ t.code }}</span></td>
          <td>{{ formatDate(t.created_at) }}</td>
          <td>{{ t.customer_name }}</td>
          <td>{{ rupiah(t.total) }}</td>
          <td>{{ payLabel(t.payment_status) }}</td>
          <td><span :class="'badge ' + badgeClass(t.order_status)">{{ statusLabel(t.order_status) }}</span></td>
        </tr>
      </tbody>
    </table>
    <p v-else class="empty">Tidak ada transaksi pada periode ini.</p>
  </section>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useTransactionStore } from '@/stores/transaction'
import { rupiah, shortDate } from '@/utils/format'
import { ORDER_STATUS, PAYMENT_STATUS } from '@/constants'

const tx = useTransactionStore()
const from = ref('')
const to = ref('')

const filtered = computed(() => {
  let list = tx.transactions
  if (from.value) list = list.filter(t => t.created_at.slice(0, 10) >= from.value)
  if (to.value) list = list.filter(t => t.created_at.slice(0, 10) <= to.value)
  return list
})

const totalRev = computed(() => filtered.value.filter(t => t.payment_status === 'lunas').reduce((s, t) => s + t.total, 0))

function formatDate (iso) { return shortDate(iso) }
function badgeClass (s) { return ORDER_STATUS.find(x => x.value === s)?.variant || '' }
function statusLabel (s) { return ORDER_STATUS.find(x => x.value === s)?.label || s }
function payLabel (s) { return PAYMENT_STATUS.find(x => x.value === s)?.label || s }
</script>

<style scoped>
.page-subtitle {
  color: rgba(255,255,255,0.5);
  font-size: 0.9rem;
  margin-top: 0.75rem;
  margin-bottom: 1.5rem;
}

.date-group {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.date-group label {
  margin: 0;
  white-space: nowrap;
}

.stat-icon {
  font-size: 1.75rem;
  margin-bottom: 0.5rem;
}

.stat-value.highlight {
  color: #2ecc71;
}

.code-badge {
  font-family: 'Courier New', monospace;
  font-size: 0.8rem;
  padding: 0.2rem 0.5rem;
  background: rgba(46,204,113,0.1);
  border: 1px solid rgba(46,204,113,0.2);
  border-radius: 0.3rem;
  color: #6eda98;
}
</style>
