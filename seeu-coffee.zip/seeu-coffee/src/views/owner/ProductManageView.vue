<template>
  <section>
    <h2>Kelola Produk</h2>
    <p class="page-subtitle">Tambah, edit, dan hapus produk menu</p>

    <!-- form -->
    <div class="form-card">
      <h3>{{ editing ? '✏️ Edit Produk' : '➕ Tambah Produk' }}</h3>
      <form @submit.prevent="save">
        <div class="form-grid">
          <div>
            <label>Nama</label>
            <input v-model="form.name" required placeholder="Nama produk" />
          </div>
          <div>
            <label>Kategori</label>
            <select v-model="form.category_id" required>
              <option disabled value="">Pilih kategori</option>
              <option v-for="c in ps.categories" :key="c.id" :value="c.id">{{ c.name }}</option>
            </select>
          </div>
          <div>
            <label>Harga (Rp)</label>
            <input v-model.number="form.price" type="number" min="0" :max="MAX_PRICE" required placeholder="0" />
          </div>
          <div>
            <label>Stok</label>
            <input v-model.number="form.stock" type="number" min="0" required placeholder="0" />
          </div>
          <div class="image-field">
            <label for="product-image">Foto Menu</label>
            <input
              id="product-image"
              ref="imageInput"
              type="file"
              accept="image/png"
              @change="handleImageChange"
            />
            <small class="image-help">Unggah PNG transparan. Gambar akan diperkecil tanpa menghilangkan transparansi.</small>
            <div v-if="form.image" class="image-preview">
              <img :src="form.image" :alt="`Pratinjau ${form.name || 'menu'}`" />
              <button type="button" class="outline" @click="removeImage">Hapus Foto</button>
            </div>
          </div>
        </div>
        <div class="form-actions">
          <button type="submit">{{ editing ? 'Simpan Perubahan' : 'Tambah Produk' }}</button>
          <button v-if="editing" type="button" class="outline" @click="resetForm">Batal</button>
        </div>
      </form>
    </div>

    <!-- table -->
    <table v-if="ps.products.length">
      <thead><tr><th>Foto</th><th>Nama</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Aksi</th></tr></thead>
      <tbody>
        <tr v-for="p in ps.products" :key="p.id">
          <td>
            <img v-if="p.image" class="product-thumbnail" :src="p.image" :alt="p.name" />
            <span v-else class="thumbnail-placeholder" aria-label="Tidak ada foto">☕</span>
          </td>
          <td><strong>{{ p.name }}</strong></td>
          <td><span class="cat-tag">{{ catName(p.category_id) }}</span></td>
          <td>{{ rupiah(p.price) }}</td>
          <td>
            <span :class="['stock-indicator', { low: p.stock <= LOW_STOCK_LIMIT }]">
              {{ p.stock }}
            </span>
          </td>
          <td class="actions">
            <button @click="edit(p)">✏️ Edit</button>
            <button class="danger" @click="remove(p.id)">🗑️ Hapus</button>
          </td>
        </tr>
      </tbody>
    </table>
  </section>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useProductStore } from '@/stores/product'
import { rupiah } from '@/utils/format'
import { LOW_STOCK_LIMIT, MAX_PRICE } from '@/constants'

const ps = useProductStore()

const empty = { name: '', category_id: '', price: 0, stock: 0, image: '' }
const form = reactive({ ...empty })
const editing = ref(null)
const imageInput = ref(null)

function catName (id) { return ps.categories.find(c => c.id === id)?.name || '-' }

function save () {
  if (editing.value) {
    const result = ps.updateProduct(editing.value, { ...form })
    if (!result.ok) { alert(Object.values(result.errors).join('\n')); return }
  } else {
    const result = ps.addProduct({ ...form, is_active: true })
    if (!result.ok) { alert(Object.values(result.errors).join('\n')); return }
  }
  resetForm()
}
function handleImageChange (event) {
  const file = event.target.files?.[0]
  if (!file) return

  if (file.type !== 'image/png') {
    alert('Gunakan PNG yang background-nya sudah transparan.')
    event.target.value = ''
    return
  }
  if (file.size > 5 * 1024 * 1024) {
    alert('Ukuran file gambar maksimal 5 MB.')
    event.target.value = ''
    return
  }

  const reader = new FileReader()
  reader.onload = () => {
    if (typeof reader.result !== 'string') {
      alert('Gambar gagal dibaca. Silakan coba file lain.')
      event.target.value = ''
      return
    }

    const image = new Image()
    image.onload = () => {
      const canvas = document.createElement('canvas')
      const context = canvas.getContext('2d')
      if (!context) {
        alert('Browser tidak dapat memproses gambar ini.')
        event.target.value = ''
        return
      }

      let scale = Math.min(1, 800 / Math.max(image.width, image.height))
      canvas.width = Math.max(1, Math.round(image.width * scale))
      canvas.height = Math.max(1, Math.round(image.height * scale))
      context.drawImage(image, 0, 0, canvas.width, canvas.height)

      const pixels = context.getImageData(0, 0, canvas.width, canvas.height).data
      let hasTransparency = false
      for (let alphaIndex = 3; alphaIndex < pixels.length; alphaIndex += 4) {
        if (pixels[alphaIndex] < 255) {
          hasTransparency = true
          break
        }
      }
      if (!hasTransparency) {
        alert('PNG ini belum transparan. Hapus background-nya terlebih dahulu, lalu unggah kembali.')
        event.target.value = ''
        return
      }

      for (let resizeAttempt = 0; resizeAttempt < 6; resizeAttempt++) {
        canvas.width = Math.max(1, Math.round(image.width * scale))
        canvas.height = Math.max(1, Math.round(image.height * scale))
        context.drawImage(image, 0, 0, canvas.width, canvas.height)

        for (const quality of [0.82, 0.68, 0.54, 0.4]) {
          const compressed = canvas.toDataURL('image/webp', quality)
          const size = Math.ceil((compressed.length - compressed.indexOf(',') - 1) * 0.75)
          if (size <= 100 * 1024) {
            form.image = compressed
            return
          }
        }
        scale *= 0.75
      }

      alert('Gambar tidak dapat diperkecil. Silakan pilih gambar lain.')
      event.target.value = ''
    }
    image.onerror = () => {
      alert('File gambar tidak dapat dibuka. Silakan pilih file lain.')
      event.target.value = ''
    }
    image.src = reader.result
  }
  reader.onerror = () => {
    alert('Gambar gagal dibaca. Silakan coba file lain.')
    event.target.value = ''
  }
  reader.readAsDataURL(file)
}
function removeImage () {
  form.image = ''
  if (imageInput.value) imageInput.value.value = ''
}
function edit (p) {
  Object.assign(form, { name: p.name, category_id: p.category_id, price: p.price, stock: p.stock, image: p.image || '' })
  editing.value = p.id
}
function resetForm () {
  Object.assign(form, empty)
  editing.value = null
  if (imageInput.value) imageInput.value.value = ''
}
function remove (id) { if (confirm('Hapus produk ini?')) ps.removeProduct(id) }
</script>

<style scoped>
.page-subtitle {
  color: rgba(255,255,255,0.5);
  font-size: 0.9rem;
  margin-top: 0.75rem;
  margin-bottom: 1.5rem;
}

.form-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0.75rem;
}

.image-field {
  grid-column: 1 / -1;
}

.image-field input[type="file"] {
  padding: 0.5rem;
}

.image-help {
  display: block;
  margin-top: 0.35rem;
  color: var(--text-muted);
}

.image-preview {
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
  margin-top: 0.75rem;
}

.image-preview img {
  width: 140px;
  height: 100px;
  object-fit: cover;
  border-radius: var(--radius-md);
  border: 1px solid var(--border-glass);
}

.product-thumbnail,
.thumbnail-placeholder {
  width: 52px;
  height: 42px;
  border-radius: 0.4rem;
  object-fit: cover;
}

.thumbnail-placeholder {
  display: inline-grid;
  place-items: center;
  background: rgba(255,255,255,0.06);
  color: var(--text-muted);
}

@media (max-width: 600px) {
  .form-grid {
    grid-template-columns: 1fr;
  }
}

.cat-tag {
  display: inline-block;
  padding: 0.15rem 0.5rem;
  background: rgba(46,204,113,0.1);
  border: 1px solid rgba(46,204,113,0.2);
  border-radius: 999px;
  font-size: 0.75rem;
  color: #6eda98;
}

.stock-indicator {
  font-weight: 600;
}

.stock-indicator.low {
  color: #ff6b6b;
}
</style>
