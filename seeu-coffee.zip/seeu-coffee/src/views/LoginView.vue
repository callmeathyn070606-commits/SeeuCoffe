<template>
  <div class="login-page">
    <router-link
      class="login-close-button"
      to="/welcome"
      aria-label="Kembali ke halaman awal"
      title="Kembali ke halaman awal"
    >
      ×
    </router-link>

    <section class="login-brand-panel">
      <img class="login-stand-photo" src="/seeu-coffee-stand.jpg" alt="Stand See U Coffee di tengah suasana hijau" />
      <span class="leaf-accent leaf-accent-top" aria-hidden="true"></span>
      <span class="leaf-accent leaf-accent-bottom" aria-hidden="true"></span>
      <div class="login-brand-content">
        <img class="login-brand-logo" src="/seeu-coffee-logo.png" alt="Logo Seeú Coffee & Space" />
        <p class="brand-eyebrow">COFFEE · NATURE · GOOD MOMENTS</p>
        <h1>See U Coffee</h1>
        <p class="brand-description">
          Temukan jeda yang nyaman, kopi favorit, dan suasana hangat untuk menikmati setiap momen.
        </p>
      </div>
      <span class="brand-location">A cozy corner to meet and unwind</span>
    </section>

    <div class="login-card">
      <div class="login-form-heading">
        <span class="login-form-kicker">SELAMAT DATANG KEMBALI</span>
        <h2>Masuk ke akun</h2>
        <p class="subtitle">Silakan masuk untuk melanjutkan</p>
      </div>
      <form @submit.prevent="handleLogin">
        <label for="username">Username</label>
        <input id="username" v-model="username" required placeholder="Masukkan username" autocomplete="username" />
        <label for="password">Password</label>
        <input id="password" v-model="password" type="password" required placeholder="Masukkan password" autocomplete="current-password" />
        <p v-if="error" class="error">{{ error }}</p>
        <button type="submit" :class="{ loading: isLoading }">
          <span v-if="!isLoading">Masuk</span>
          <span v-else>Memproses...</span>
        </button>
      </form>

      <div class="login-hint">
        <p>Demo akun:</p>
        <div class="hint-accounts">
          <span @click="fillDemo('owner','owner123')">👤 Pemilik</span>
          <span @click="fillDemo('kasir1','kasir123')">🧑‍💼 Kasir</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { HOME_BY_ROLE } from '@/constants'

const auth = useAuthStore()
const router = useRouter()
const username = ref('')
const password = ref('')
const error = ref('')
const isLoading = ref(false)

function fillDemo (u, p) {
  username.value = u
  password.value = p
  error.value = ''
}

async function handleLogin () {
  isLoading.value = true
  error.value = ''
  // Simulate a brief delay for UX
  await new Promise(r => setTimeout(r, 400))
  const ok = auth.login(username.value, password.value)
  isLoading.value = false
  if (!ok) { error.value = 'Username atau password salah'; return }
  router.push(HOME_BY_ROLE[auth.user.role])
}
</script>

<style scoped>
.login-page {
  position: relative;
  display: grid;
  grid-template-columns: minmax(0, 1.15fr) minmax(380px, 0.85fr);
  align-items: stretch;
  justify-content: stretch;
  gap: clamp(2rem, 6vw, 6rem);
  padding: clamp(1.25rem, 5vw, 5rem);
}

.login-close-button {
  position: absolute;
  top: 1.25rem;
  right: 1.5rem;
  z-index: 5;
  width: 2.5rem;
  height: 2.5rem;
  display: grid;
  place-items: center;
  border: 1px solid rgba(255,255,255,0.35);
  border-radius: 50%;
  background: rgba(5, 23, 14, 0.72);
  color: #fff;
  font-size: 1.5rem;
  line-height: 1;
  text-decoration: none;
  transition: background 0.2s ease, transform 0.2s ease;
}

.login-close-button:hover {
  transform: scale(1.06);
  background: rgba(46, 204, 113, 0.35);
}

.login-brand-panel {
  min-height: min(760px, calc(100vh - 10rem));
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: center;
  overflow: hidden;
  padding: clamp(2rem, 5vw, 5rem);
  border: 1px solid rgba(220, 239, 218, 0.14);
  border-radius: 2rem;
  background: #102a1b;
  box-shadow: 0 28px 80px rgba(0, 0, 0, 0.28);
}

.login-brand-panel::after {
  content: '';
  position: absolute;
  inset: 0;
  pointer-events: none;
  background:
    linear-gradient(90deg, rgba(5, 23, 14, 0.90) 0%, rgba(5, 23, 14, 0.72) 48%, rgba(5, 23, 14, 0.18) 100%),
    linear-gradient(0deg, rgba(5, 23, 14, 0.52), transparent 38%);
}

.login-stand-photo {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center;
  opacity: 0.76;
}

.leaf-accent {
  position: absolute;
  z-index: 1;
  width: 138px;
  height: 150px;
  pointer-events: none;
  opacity: 0.82;
  filter: drop-shadow(0 3px 8px rgba(2, 18, 9, 0.5));
  background:
    radial-gradient(ellipse 17px 8px at 26% 20%, #b7d69b 0 58%, transparent 66%),
    radial-gradient(ellipse 18px 8px at 47% 32%, #779f61 0 58%, transparent 66%),
    radial-gradient(ellipse 18px 8px at 31% 43%, #a9cb8b 0 58%, transparent 66%),
    radial-gradient(ellipse 17px 8px at 57% 54%, #75975c 0 58%, transparent 66%),
    radial-gradient(ellipse 17px 8px at 43% 68%, #a9cb8b 0 58%, transparent 66%),
    linear-gradient(133deg, transparent 48.8%, rgba(182, 211, 147, 0.82) 49.4% 50.2%, transparent 50.8%);
}

.leaf-accent-top {
  top: 0.65rem;
  left: 0.65rem;
  transform: rotate(-13deg);
}

.leaf-accent-bottom {
  right: 0.65rem;
  bottom: 0.65rem;
  transform: rotate(167deg);
}

.login-brand-content,
.brand-location {
  position: relative;
  z-index: 1;
}

.login-brand-content {
  max-width: 570px;
}

.login-brand-logo {
  display: block;
  width: min(300px, 72%);
  height: auto;
  margin: 0 0 2.5rem;
  filter: drop-shadow(0 12px 24px rgba(0, 0, 0, 0.28));
}

.brand-eyebrow,
.login-form-kicker {
  color: #b7d7a1;
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 0.18em;
}

.login-brand-content h1 {
  margin: 0.75rem 0 0.8rem;
  color: #f7f5e8;
  font-family: var(--font-heading);
  font-size: clamp(2.5rem, 5vw, 4.5rem);
  line-height: 1.05;
  letter-spacing: -0.045em;
}

.brand-description {
  max-width: 440px;
  color: rgba(245, 245, 230, 0.82);
  font-size: clamp(1rem, 1.5vw, 1.15rem);
  line-height: 1.8;
}

.brand-location {
  position: absolute;
  bottom: 1.5rem;
  left: clamp(2rem, 5vw, 5rem);
  color: rgba(245, 245, 230, 0.68);
  font-size: 0.75rem;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}

.login-card {
  align-self: center;
  justify-self: center;
  max-width: 460px;
  padding: clamp(2rem, 4vw, 3.25rem);
  text-align: left;
  border-radius: 1.5rem;
}

.login-form-heading {
  margin-bottom: 2rem;
}

.login-form-heading h2 {
  display: block;
  margin: 0.65rem 0 0.35rem;
  color: #f5f8f1;
  font-family: var(--font-heading);
  font-size: 1.8rem;
}

.login-form-heading h2::after {
  display: none;
}

.login-card .subtitle {
  margin: 0;
}

.login-card label {
  margin-top: 0.9rem;
}

.login-card input {
  margin-bottom: 0.35rem;
}

.login-card button[type="submit"] {
  margin-top: 0.55rem;
}

@keyframes float {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-8px); }
}

.login-hint {
  margin-top: 1.5rem;
  padding-top: 1.25rem;
  border-top: 1px solid rgba(255,255,255,0.08);
}

.login-hint p {
  font-size: 0.75rem;
  color: rgba(255,255,255,0.4);
  margin-bottom: 0.5rem;
}

.hint-accounts {
  display: flex;
  gap: 0.5rem;
  justify-content: flex-start;
  flex-wrap: wrap;
}

.hint-accounts span {
  font-size: 0.75rem;
  padding: 0.3rem 0.65rem;
  background: rgba(255,255,255,0.05);
  border: 1px solid rgba(255,255,255,0.1);
  border-radius: 999px;
  cursor: pointer;
  color: rgba(255,255,255,0.6);
  transition: all 0.2s ease;
}

.hint-accounts span:hover {
  background: rgba(46, 204, 113, 0.15);
  border-color: rgba(46, 204, 113, 0.3);
  color: #2ecc71;
}

button.loading {
  opacity: 0.7;
  pointer-events: none;
}

@media (max-width: 900px) {
  .login-page {
    grid-template-columns: minmax(0, 1fr) minmax(340px, 0.9fr);
    gap: 1.5rem;
    padding: 1.5rem;
  }

  .login-brand-panel {
    min-height: min(680px, calc(100vh - 3rem));
    padding: 2rem;
  }

  .brand-location {
    left: 2rem;
  }
}

@media (max-width: 700px) {
  .login-page {
    grid-template-columns: 1fr;
    gap: 1rem;
    padding: 1rem;
  }

  .login-brand-panel {
    min-height: 360px;
    padding: 1.75rem;
    border-radius: 1.5rem;
  }

  .login-brand-panel::after {
    background:
      linear-gradient(90deg, rgba(5, 23, 14, 0.82), rgba(5, 23, 14, 0.36)),
      linear-gradient(0deg, rgba(5, 23, 14, 0.58), transparent 60%);
  }

  .login-brand-logo {
    width: min(220px, 65%);
    margin-bottom: 1.5rem;
  }

  .login-brand-content h1 {
    font-size: 2.6rem;
  }

  .brand-location {
    bottom: 1.1rem;
    left: 1.75rem;
  }

  .login-card {
    width: 100%;
    max-width: none;
    margin: 0;
    padding: 1.75rem;
  }
}
</style>
