<template>
  <section>
    <h2>Keuangan Kasir</h2>
    <p class="page-subtitle">Ringkasan pemasukan dari transaksi lunas dan pengeluaran operasional.</p>

    <div class="stat-grid finance-summary">
      <article class="stat-card">
        <div class="stat-icon">💰</div>
        <span class="stat-label">Total Pemasukan</span>
        <span class="stat-value highlight">{{ rupiah(totalIncome) }}</span>
        <small>Dari transaksi berstatus lunas</small>
      </article>
      <article class="stat-card">
        <div class="stat-icon">🧾</div>
        <span class="stat-label">Total Pengeluaran</span>
        <span class="stat-value">{{ rupiah(totalExpenses) }}</span>
        <small>{{ expenses.length }} catatan pengeluaran</small>
      </article>
      <article class="stat-card">
        <div class="stat-icon">📊</div>
        <span class="stat-label">Saldo Bersih</span>
        <span class="stat-value" :class="{ negative: netBalance < 0 }">{{ rupiah(netBalance) }}</span>
        <small>Pemasukan dikurangi pengeluaran</small>
      </article>
    </div>

    <div class="finance-layout">
      <form class="form-card expense-form" @submit.prevent="addExpense">
        <h3>Catat Pengeluaran</h3>
        <label for="expense-description">Keterangan</label>
        <input
          id="expense-description"
          v-model.trim="description"
          maxlength="100"
          required
          placeholder="Contoh: pembelian bahan baku"
        />

        <label for="expense-amount">Jumlah pengeluaran</label>
        <input id="expense-amount" v-model="amount" type="number" min="1" step="1" required placeholder="0" />

        <label for="expense-date">Tanggal</label>
        <input id="expense-date" v-model="date" type="date" required />

        <p v-if="errorMessage" class="form-error" role="alert">{{ errorMessage }}</p>
        <button class="btn-primary" type="submit">Simpan Pengeluaran</button>
      </form>

      <div class="expense-history">
        <h3>Riwayat Pengeluaran</h3>
        <table v-if="sortedExpenses.length">
          <thead>
            <tr><th>Tanggal</th><th>Keterangan</th><th>Jumlah</th><th>Aksi</th></tr>
          </thead>
          <tbody>
            <tr v-for="expense in sortedExpenses" :key="expense.id">
              <td>{{ formatDate(expense.date) }}</td>
              <td>{{ expense.description }}</td>
              <td>{{ rupiah(expense.amount) }}</td>
              <td>
                <button class="delete-expense" type="button" @click="removeExpense(expense.id)">Hapus</button>
              </td>
            </tr>
          </tbody>
        </table>
        <p v-else class="empty">Belum ada pengeluaran yang dicatat.</p>
      </div>
    </div>
  </section>
</template>

<script setup>
import { computed, ref } from 'vue'
import { useTransactionStore } from '@/stores/transaction'
import { STORAGE_KEYS } from '@/constants'
import { loadData, saveData } from '@/services/storage'
import { rupiah } from '@/utils/format'

const tx = useTransactionStore()
const storedExpenses = loadData(STORAGE_KEYS.expenses)
const expenses = ref(Array.isArray(storedExpenses) ? storedExpenses : [])
const description = ref('')
const amount = ref('')
const date = ref(todayDate())
const errorMessage = ref('')

const totalIncome = computed(() => tx.totalRevenue)
const totalExpenses = computed(() => expenses.value.reduce((sum, expense) => sum + Number(expense.amount || 0), 0))
const netBalance = computed(() => totalIncome.value - totalExpenses.value)
const sortedExpenses = computed(() => [...expenses.value].sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id))

function formatDate (value) {
  return new Date(`${value}T00:00:00`).toLocaleDateString('id-ID', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  })
}

function todayDate () {
  const now = new Date()
  const month = String(now.getMonth() + 1).padStart(2, '0')
  const day = String(now.getDate()).padStart(2, '0')
  return `${now.getFullYear()}-${month}-${day}`
}

function addExpense () {
  errorMessage.value = ''
  const parsedAmount = Number(amount.value)
  if (!description.value || !Number.isSafeInteger(parsedAmount) || parsedAmount <= 0 || !date.value) {
    errorMessage.value = 'Isi keterangan, jumlah positif, dan tanggal pengeluaran dengan benar.'
    return
  }

  const nextExpense = {
    id: expenses.value.reduce((max, expense) => Math.max(max, Number(expense.id) || 0), 0) + 1,
    description: description.value,
    amount: parsedAmount,
    date: date.value
  }
  const updatedExpenses = [...expenses.value, nextExpense]

  try {
    saveData(STORAGE_KEYS.expenses, updatedExpenses)
  } catch {
    errorMessage.value = 'Pengeluaran gagal disimpan. Periksa ruang penyimpanan browser.'
    return
  }

  expenses.value = updatedExpenses
  description.value = ''
  amount.value = ''
  date.value = todayDate()
}

function removeExpense (id) {
  errorMessage.value = ''
  const updatedExpenses = expenses.value.filter(expense => expense.id !== id)
  try {
    saveData(STORAGE_KEYS.expenses, updatedExpenses)
  } catch {
    errorMessage.value = 'Pengeluaran gagal dihapus. Periksa ruang penyimpanan browser.'
    return
  }
  expenses.value = updatedExpenses
}
</script>

<style scoped>
.page-subtitle {
  margin: 0.75rem 0 1.5rem;
  color: var(--text-muted);
}

.finance-summary {
  margin-bottom: 1.5rem;
}

.stat-card {
  display: grid;
  gap: 0.35rem;
}

.stat-icon {
  font-size: 1.5rem;
}

.stat-label,
.stat-card small {
  color: var(--text-secondary);
}

.stat-value {
  font-size: clamp(1.2rem, 2vw, 1.65rem);
  font-weight: 700;
  overflow-wrap: anywhere;
}

.highlight {
  color: #a0d4a0;
}

.negative {
  color: #ffaaa0;
}

.finance-layout {
  display: grid;
  grid-template-columns: minmax(250px, 320px) minmax(0, 1fr);
  gap: 1.25rem;
  align-items: start;
}

.expense-form {
  display: grid;
  gap: 0.7rem;
}

.expense-form h3,
.expense-history h3 {
  margin-bottom: 0.25rem;
}

.expense-form .btn-primary {
  margin-top: 0.4rem;
}

.form-error {
  color: #ffaaa0;
  font-size: 0.85rem;
}

.expense-history {
  min-width: 0;
}

.expense-history table {
  margin-top: 0.75rem;
}

.delete-expense {
  border: 1px solid rgba(255, 107, 107, 0.25);
  border-radius: var(--radius-sm);
  padding: 0.3rem 0.6rem;
  background: rgba(255, 107, 107, 0.08);
  color: #ffaaa0;
}

.delete-expense:hover {
  background: rgba(255, 107, 107, 0.16);
}

@media (max-width: 800px) {
  .finance-layout {
    grid-template-columns: 1fr;
  }
}
</style>
