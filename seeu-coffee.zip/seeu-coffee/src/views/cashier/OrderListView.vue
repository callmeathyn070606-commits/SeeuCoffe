<template>
  <section>
    <h2>Daftar Pesanan</h2>
    <p class="page-subtitle">Kelola status dan pembayaran pesanan</p>

    <div class="toolbar">
      <select v-model="filterStatus">
        <option value="">Semua status</option>
        <option v-for="s in ORDER_STATUS" :key="s.value" :value="s.value">{{ s.label }}</option>
      </select>
      <span class="order-count">{{ filtered.length }} pesanan</span>
    </div>

    <table v-if="filtered.length">
      <thead><tr><th>Kode</th><th>Pelanggan</th><th>Jenis pesanan</th><th>Item</th><th>Total</th><th>Bayar</th><th>Bukti</th><th>Status</th><th>Aksi</th></tr></thead>
      <tbody>
        <tr v-for="t in filtered" :key="t.id">
          <td><span class="code-badge">{{ t.code }}</span></td>
          <td>{{ t.customer_name }}</td>
          <td>{{ orderTypeLabel(t.order_type) }}</td>
          <td class="items-cell">{{ t.items.map(i => i.name + ' x' + i.qty).join(', ') }}</td>
          <td>{{ rupiah(t.total) }}</td>
          <td><span :class="'badge ' + payBadge(t.payment_status)">{{ payLabel(t.payment_status) }}</span></td>
          <td>
            <a v-if="t.payment_proof" :href="t.payment_proof" :download="`bukti-${t.code}.webp`">Unduh bukti</a>
            <span v-else>—</span>
          </td>
          <td><span :class="'badge ' + badgeClass(t.order_status)">{{ statusLabel(t.order_status) }}</span></td>
          <td class="actions">
            <button v-if="t.order_status==='diproses'" @click="advance(t,'siap')">✅ Siap</button>
            <button v-if="t.order_status==='siap'" @click="advance(t,'selesai')">🏁 Selesai</button>
            <button v-if="t.payment_status==='belum_dibayar'" class="outline" @click="pay(t)">💳 Bayar</button>
          </td>
        </tr>
      </tbody>
    </table>
    <p v-else class="empty">Tidak ada pesanan.</p>
  </section>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useTransactionStore } from '@/stores/transaction'
import { rupiah } from '@/utils/format'
import { ORDER_STATUS, ORDER_TYPES, PAYMENT_STATUS } from '@/constants'

const tx = useTransactionStore()
const filterStatus = ref('')

const filtered = computed(() => {
  let list = [...tx.transactions].reverse()
  if (filterStatus.value) list = list.filter(t => t.order_status === filterStatus.value)
  return list
})

function badgeClass (s) { return ORDER_STATUS.find(x => x.value === s)?.variant || '' }
function statusLabel (s) { return ORDER_STATUS.find(x => x.value === s)?.label || s }
function orderTypeLabel (s) { return ORDER_TYPES.find(x => x.value === s)?.label || '—' }
function payBadge (s) { return PAYMENT_STATUS.find(x => x.value === s)?.variant || '' }
function payLabel (s) { return PAYMENT_STATUS.find(x => x.value === s)?.label || s }

function advance (t, next) { tx.updateStatus(t.id, { order_status: next }) }
function pay (t) { tx.updateStatus(t.id, { payment_status: 'lunas' }) }
</script>

<style scoped>
.page-subtitle {
  color: rgba(255,255,255,0.5);
  font-size: 0.9rem;
  margin-top: -1rem;
  margin-bottom: 1.5rem;
}

.order-count {
  font-size: 0.8rem;
  color: rgba(255,255,255,0.4);
  padding: 0.4rem 0.75rem;
  background: rgba(255,255,255,0.03);
  border-radius: 999px;
  border: 1px solid rgba(255,255,255,0.08);
}

.code-badge {
  font-family: 'Courier New', monospace;
  font-size: 0.8rem;
  padding: 0.2rem 0.5rem;
  background: rgba(46,204,113,0.1);
  border: 1px solid rgba(46,204,113,0.2);
  border-radius: 0.3rem;
  color: #6eda98;
}

.items-cell {
  max-width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 0.8rem;
  color: rgba(255,255,255,0.6);
}

</style>
