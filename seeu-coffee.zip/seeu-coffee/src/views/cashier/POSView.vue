<template>
  <section>
    <div class="pos-header">
      <h2>Kasir (POS)</h2>
      <p class="page-subtitle">Buat pesanan baru untuk pelanggan</p>
    </div>

    <div class="pos-layout">
      <div class="pos-menu">
        <div class="pos-toolbar">
          <div class="search-box">
            <span class="search-icon">🔍</span>
            <input v-model="search" placeholder="Cari produk..." class="search" />
          </div>

          <div class="category-tags" v-if="categories.length">
            <button
              v-for="category in [{ id: '', name: 'Semua' }, ...categories]"
              :key="category.id"
              type="button"
              :class="['tag', { active: catFilter === category.id }]"
              @click="catFilter = category.id"
            >
              {{ category.name }}
            </button>
          </div>
        </div>

        <div class="pos-product-grid">
          <div v-for="p in filtered" :key="p.id" class="pos-product-card">
            <div class="card-category">{{ getCatName(p.category_id) }}</div>
            <div class="catalog-image-frame">
              <img v-if="p.image" class="catalog-product-image" :src="p.image" :alt="p.name" />
              <div v-else class="catalog-image-placeholder" aria-hidden="true">☕</div>
            </div>
            <div class="pos-card-body">
              <p class="product-id">ID Menu #{{ p.id }}</p>
              <h3>{{ p.name }}</h3>
              <p class="mini-price">{{ rupiah(p.price) }}</p>
              <p class="stock" :class="{ low: p.stock <= LOW_STOCK_LIMIT }">
                <span v-if="p.stock > LOW_STOCK_LIMIT">✓ Tersedia</span>
                <span v-else-if="p.stock > 0">⚠ Stok terbatas ({{ p.stock }})</span>
                <span v-else>✕ Habis</span>
              </p>
              <button
                type="button"
                class="btn-primary pos-add-button"
                :disabled="p.stock <= 0"
                @click="addItem(p)"
              >
                {{ p.stock > 0 ? 'Tambah ke Keranjang' : 'Stok Habis' }}
              </button>
            </div>
          </div>
        </div>
        <p v-if="filtered.length === 0" class="empty">Produk tidak ditemukan.</p>
      </div>

      <!-- cart -->
      <div class="pos-cart">
        <h3>🛒 Keranjang <span class="cart-count" v-if="txStore.cart.length">{{ txStore.cart.length }}</span></h3>
        <div v-if="txStore.cart.length === 0" class="empty-cart">
          <span class="empty-cart-icon">🛒</span>
          <p>Keranjang kosong</p>
          <small>Klik produk untuk menambahkan</small>
        </div>
        <div v-for="item in txStore.cart" :key="item.product_id" class="cart-row">
          <span class="cart-item-name">{{ item.name }}</span>
          <div class="qty-ctrl">
            <button @click="decQty(item)">−</button>
            <span>{{ item.qty }}</span>
            <button @click="incQty(item)">+</button>
          </div>
          <span class="cart-item-price">{{ rupiah(item.unit_price * item.qty) }}</span>
          <button class="remove" @click="txStore.removeFromCart(item.product_id)">✕</button>
        </div>

        <div class="cart-footer" v-if="txStore.cart.length > 0">
          <div class="divider"></div>
          <label>Nama Pelanggan</label>
          <input v-model="customerName" :placeholder="DEFAULT_CUSTOMER_NAME" />
          <label>Metode Bayar</label>
          <select v-model="payMethod">
            <option v-for="m in PAYMENT_METHODS" :key="m.value" :value="m.value">{{ m.label }}</option>
          </select>
          <div class="total">Total: {{ rupiah(txStore.cartTotal) }}</div>
          <button class="btn-primary" :disabled="txStore.cart.length===0" @click="submit">
            🧾 Buat Pesanan
          </button>
        </div>
      </div>
    </div>

    <!-- Nota modal -->
    <div v-if="lastTransaction" class="nota-overlay" @click.self="lastTransaction = null">
      <div class="nota-card">
        <h3>✅ Pesanan Berhasil!</h3>
        <p class="nota-code">{{ lastTransaction.code }}</p>
        <p>Pelanggan: {{ lastTransaction.customer_name }}</p>
        <p>Total: <strong>{{ rupiah(lastTransaction.total) }}</strong></p>
        <button class="btn-primary" @click="lastTransaction = null">Tutup</button>
      </div>
    </div>
  </section>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useProductStore } from '@/stores/product'
import { useTransactionStore } from '@/stores/transaction'
import { useAuthStore } from '@/stores/auth'
import { rupiah } from '@/utils/format'
import { PAYMENT_METHODS, DEFAULT_CUSTOMER_NAME, LOW_STOCK_LIMIT } from '@/constants'

const ps = useProductStore()
const txStore = useTransactionStore()
const auth = useAuthStore()

const search = ref('')
const catFilter = ref('')
const customerName = ref('')
const payMethod = ref('tunai')
const lastTransaction = ref(null)

const categories = computed(() => ps.categories)
const filtered = computed(() => {
  let list = ps.activeProducts
  if (catFilter.value !== '') {
    list = list.filter(p => String(p.category_id) === String(catFilter.value))
  }
  if (search.value) {
    const q = search.value.toLowerCase()
    list = list.filter(p => p.name.toLowerCase().includes(q))
  }
  return list
})

function getCatName (id) {
  return ps.categoryName(id)
}

function addItem (p) {
  txStore.addToCart(p)
}

function incQty (item) {
  const product = ps.findById(item.product_id)
  if (product && item.qty < product.stock) {
    txStore.changeQty(item.product_id, item.qty + 1)
  }
}

function decQty (item) {
  if (item.qty > 1) {
    txStore.changeQty(item.product_id, item.qty - 1)
  } else {
    txStore.removeFromCart(item.product_id)
  }
}

function submit () {
  const result = txStore.createTransaction({
    customer_name: customerName.value || DEFAULT_CUSTOMER_NAME,
    payment_method: payMethod.value
  }, auth.user?.id)

  if (result.ok) {
    lastTransaction.value = result.data
    customerName.value = ''
  } else {
    alert(result.message || 'Gagal membuat pesanan')
  }
}
</script>

<style scoped>
.pos-header {
  margin-bottom: 1.5rem;
}

.page-subtitle {
  color: rgba(255,255,255,0.5);
  font-size: 0.9rem;
  margin-top: 0.75rem;
}

.search-box {
  position: relative;
  width: 100%;
  max-width: 320px;
  margin-bottom: 1.25rem;
}

.pos-toolbar {
  position: sticky;
  top: 0;
  z-index: 20;
  padding: 0.25rem 0 0.15rem;
  background: linear-gradient(
    180deg,
    rgba(7, 27, 18, 1) 0%,
    rgba(7, 27, 18, 0.96) 75%,
    rgba(7, 27, 18, 0) 100%
  );
}

.pos-toolbar .search-box {
  margin-bottom: 0.75rem;
}

.pos-toolbar .category-tags {
  margin-bottom: 0.9rem;
}

.search-icon {
  position: absolute;
  left: 0.75rem;
  top: 50%;
  transform: translateY(-50%);
  font-size: 0.85rem;
  opacity: 0.5;
}

.search-box input {
  padding-left: 2.25rem;
}

.category-tags {
  display: flex;
  gap: 0.4rem;
  flex-wrap: wrap;
  margin-bottom: 1.25rem;
}

.tag {
  padding: 0.4rem 0.9rem;
  border-radius: 999px;
  font-size: 0.8rem;
  font-weight: 500;
  border: 1px solid rgba(255,255,255,0.1);
  background: rgba(255,255,255,0.03);
  color: rgba(255,255,255,0.6);
  cursor: pointer;
  transition: all 0.2s ease;
}

.tag:hover {
  background: rgba(46,204,113,0.1);
  border-color: rgba(46,204,113,0.2);
  color: rgba(255,255,255,0.8);
}

.tag.active {
  background: linear-gradient(135deg, #14612a, #1a7a35);
  border-color: #22994a;
  color: #fff;
  box-shadow: 0 2px 10px rgba(46,204,113,0.2);
}

.pos-layout {
  align-items: start;
  height: calc(100vh - 20.5rem);
  height: calc(100dvh - 20.5rem);
  min-height: 18rem;
}

.pos-menu {
  min-height: 0;
  height: 100%;
  overflow-y: auto;
  overscroll-behavior-y: contain;
  padding-right: 0.25rem;
}

.pos-product-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 1rem;
}

.pos-product-card {
  position: relative;
  overflow: hidden;
  text-align: center;
  border: 1px solid var(--border-glass);
  border-radius: var(--radius-lg);
  background:
    linear-gradient(145deg, rgba(255,255,255,0.035), transparent 42%),
    rgba(13, 48, 31, 0.84);
  box-shadow: 0 16px 38px rgba(0, 0, 0, 0.24);
  transition: all 0.25s ease;
}

.pos-product-card:hover {
  transform: translateY(-3px);
  border-color: rgba(145, 202, 158, 0.28);
  box-shadow: 0 22px 50px rgba(0, 0, 0, 0.28);
}

.card-category {
  padding: 0.4rem 0.75rem;
  font-size: 0.7rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: rgba(255,255,255,0.4);
  background: rgba(255,255,255,0.03);
  border-bottom: 1px solid rgba(255,255,255,0.05);
}

.catalog-image-frame {
  width: min(100%, 180px);
  aspect-ratio: 9 / 16;
  height: auto;
  margin: 0 auto;
  display: grid;
  place-items: center;
  overflow: hidden;
  background: radial-gradient(ellipse at center, rgba(121, 164, 125, 0.12), transparent 72%);
}

.catalog-product-image {
  width: 100%;
  height: 100%;
  padding: 0.65rem;
  object-fit: contain;
  filter: drop-shadow(0 10px 14px rgba(0, 0, 0, 0.24));
}

.catalog-image-placeholder {
  width: 100%;
  height: 100%;
  display: grid;
  place-items: center;
  color: rgba(191, 208, 193, 0.45);
  font-size: 2rem;
}

.pos-card-body {
  padding: 1.25rem 1rem 1.5rem;
}

.pos-card-body h3 {
  font-size: 1.05rem;
  margin-bottom: 0.35rem;
}

.product-id {
  margin-bottom: 0.2rem;
  color: var(--text-muted);
  font-size: 0.68rem;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}

.stock {
  margin-top: 0.4rem;
  font-size: 0.78rem;
  color: #80c997;
}

.stock.low {
  color: #ff6b6b;
}

.pos-add-button {
  width: 100%;
  margin-top: 0.9rem;
  padding: 0.6rem 0.75rem;
  font-size: 0.82rem;
}

.pos-add-button:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

.pos-cart {
  min-height: 0;
  height: 100%;
  position: sticky;
  top: 5rem;
  max-height: calc(100vh - 7rem);
  max-height: calc(100dvh - 7rem);
  overflow-y: auto;
}

.add-indicator {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  width: 1.4rem;
  height: 1.4rem;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(46,204,113,0.15);
  border: 1px solid rgba(46,204,113,0.3);
  border-radius: 50%;
  color: #2ecc71;
  font-size: 0.85rem;
  font-weight: 700;
  opacity: 0;
  transition: all 0.2s ease;
}

.product-card-mini:hover .add-indicator {
  opacity: 1;
}

.mini-price {
  color: #2ecc71 !important;
  font-weight: 600 !important;
}

.cart-count {
  display: inline-block;
  min-width: 1.3rem;
  height: 1.3rem;
  line-height: 1.3rem;
  text-align: center;
  background: linear-gradient(135deg, #14612a, #1a7a35);
  border-radius: 50%;
  font-size: 0.7rem;
  margin-left: 0.4rem;
  vertical-align: middle;
}

.empty-cart {
  text-align: center;
  padding: 2rem 1rem;
  color: rgba(255,255,255,0.3);
}

.empty-cart-icon {
  font-size: 2.5rem;
  display: block;
  margin-bottom: 0.5rem;
  opacity: 0.3;
}

.empty-cart p {
  font-size: 0.9rem;
  margin-bottom: 0.25rem;
}

.empty-cart small {
  font-size: 0.75rem;
  opacity: 0.6;
}

.cart-item-name {
  flex: 1;
  font-weight: 500;
}

.cart-item-price {
  font-weight: 600;
  color: #2ecc71;
  font-size: 0.85rem;
  min-width: 80px;
  text-align: right;
}

.divider {
  height: 1px;
  background: rgba(255,255,255,0.08);
  margin: 0.75rem 0;
}

/* Nota modal */
.nota-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.6);
  backdrop-filter: blur(4px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 200;
  animation: fadeIn 0.2s ease;
}

.nota-card {
  background: rgba(15, 40, 15, 0.95);
  backdrop-filter: blur(20px);
  padding: 2rem;
  border-radius: 1rem;
  border: 1px solid rgba(46,204,113,0.2);
  box-shadow: 0 8px 40px rgba(0,0,0,0.5);
  text-align: center;
  max-width: 380px;
  width: 90%;
  animation: scaleIn 0.3s ease;
}

.nota-card h3 {
  color: #2ecc71;
  margin-bottom: 1rem;
}

.nota-code {
  font-family: 'Courier New', monospace;
  font-size: 1.3rem;
  font-weight: 700;
  color: #6eda98;
  padding: 0.5rem 1rem;
  background: rgba(46,204,113,0.1);
  border: 1px solid rgba(46,204,113,0.2);
  border-radius: 0.5rem;
  display: inline-block;
  margin-bottom: 0.75rem;
}

.nota-card p {
  margin-bottom: 0.4rem;
  color: rgba(255,255,255,0.8);
}

.nota-card strong {
  color: #2ecc71;
}

.nota-card .btn-primary {
  margin-top: 1rem;
}

@media (max-width: 900px) {
  .pos-layout {
    height: auto;
  }

  .pos-menu,
  .pos-cart {
    height: 70vh;
    height: 70dvh;
  }

  .pos-cart {
    position: static;
  }
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes scaleIn {
  from { opacity: 0; transform: scale(0.95); }
  to { opacity: 1; transform: scale(1); }
}
</style>
