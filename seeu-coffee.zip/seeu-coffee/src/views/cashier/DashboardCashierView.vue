<script setup>
import CashierDashboard from './CashierDashboard.vue'
</script>

<template>
  <CashierDashboard />
</template>
