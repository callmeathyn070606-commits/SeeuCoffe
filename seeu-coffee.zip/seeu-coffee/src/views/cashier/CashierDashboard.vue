<template>
  <section>
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem; margin-bottom: 1.5rem;">
      <div>
        <h2>Dashboard Kasir</h2>
        <p class="page-subtitle" style="margin-bottom: 0;">Ringkasan aktivitas kasir</p>
      </div>
      <router-link to="/kasir/pos">
        <button class="btn-primary">➕ Buat Pesanan Baru</button>
      </router-link>
    </div>

    <div class="stat-grid">
      <div class="stat-card">
        <div class="stat-icon">📋</div>
        <span class="stat-label">Total Pesanan</span>
        <span class="stat-value">{{ tx.transactions.length }}</span>
      </div>
      <div class="stat-card">
        <div class="stat-icon">💵</div>
        <span class="stat-label">Total Pendapatan</span>
        <span class="stat-value highlight">{{ rupiah(tx.totalRevenue) }}</span>
      </div>
      <div class="stat-card">
        <div class="stat-icon">⏳</div>
        <span class="stat-label">Pesanan Diproses</span>
        <span class="stat-value" :class="{ warn: processingCount > 0 }">{{ processingCount }}</span>
      </div>
    </div>

    <h3 style="margin-top:2rem">Pesanan Terbaru</h3>
    <table v-if="recent.length">
      <thead><tr><th>Kode</th><th>Pelanggan</th><th>Total</th><th>Status</th></tr></thead>
      <tbody>
        <tr v-for="t in recent" :key="t.id">
          <td><span class="code-badge">{{ t.code }}</span></td>
          <td>{{ t.customer_name }}</td>
          <td>{{ rupiah(t.total) }}</td>
          <td><span :class="'badge ' + badgeClass(t.order_status)">{{ statusLabel(t.order_status) }}</span></td>
        </tr>
      </tbody>
    </table>
    <p v-else class="empty">Belum ada pesanan.</p>
  </section>
</template>

<script setup>
import { computed } from 'vue'
import { useTransactionStore } from '@/stores/transaction'
import { rupiah } from '@/utils/format'
import { ORDER_STATUS } from '@/constants'

const tx = useTransactionStore()
const today = new Date().toISOString().slice(0, 10)

const todayOrders = computed(() => tx.transactions.filter(t => t.created_at.startsWith(today)))
const todayRevenue = computed(() => todayOrders.value.reduce((s, t) => s + (t.payment_status === 'lunas' ? t.total : 0), 0))
const processingCount = computed(() => tx.transactions.filter(t => t.order_status === 'diproses').length)
const recent = computed(() => [...tx.transactions].reverse().slice(0, 5))

function badgeClass (status) { return ORDER_STATUS.find(s => s.value === status)?.variant || '' }
function statusLabel (status) { return ORDER_STATUS.find(s => s.value === status)?.label || status }
</script>

<style scoped>
.page-subtitle {
  color: rgba(255,255,255,0.5);
  font-size: 0.9rem;
  margin-top: -1rem;
  margin-bottom: 1.5rem;
}

.stat-icon {
  font-size: 1.75rem;
  margin-bottom: 0.5rem;
}

.stat-value.highlight {
  color: #2ecc71;
}

.code-badge {
  font-family: 'Courier New', monospace;
  font-size: 0.8rem;
  padding: 0.2rem 0.5rem;
  background: rgba(46,204,113,0.1);
  border: 1px solid rgba(46,204,113,0.2);
  border-radius: 0.3rem;
  color: #6eda98;
}
</style>
