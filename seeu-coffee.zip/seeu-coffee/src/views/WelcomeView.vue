<template>
  <div class="welcome-page">
    <aside class="welcome-sidebar">
      <div class="sidebar-brand">
        <span class="sidebar-brand-mark" aria-hidden="true">S</span>
        <span class="sidebar-brand-name">SeeU <small>COFFEE</small></span>
      </div>
      <p class="sidebar-caption">AREA STAFF</p>
      <router-link class="dashboard-link" to="/dashboard">
        <span class="dashboard-icon" aria-hidden="true">▦</span>
        <span>Dashboard</span>
        <span class="dashboard-arrow" aria-hidden="true">›</span>
      </router-link>
    </aside>

    <main class="welcome-main">
      <img class="welcome-logo" src="/seeu-coffee-logo.png" alt="Logo Seeú Coffee & Space" />
      <p class="welcome-eyebrow">COFFEE · NATURE · GOOD MOMENTS</p>
      <h1>See U Coffee</h1>
      <p class="welcome-description">
        Nikmati racikan kopi pilihan dan suasana nyaman untuk bersantai, bekerja, atau berkumpul.
        Pilih menu favorit Anda dan pesan dengan mudah melalui katalog.
      </p>
      <router-link class="order-button" to="/katalog">🛒 Pesan</router-link>
    </main>
  </div>
</template>

<style scoped>
.welcome-page {
  min-height: 100vh;
  display: grid;
  grid-template-columns: 220px minmax(0, 1fr);
  color: #f7f5e8;
  background: #071b12;
}

.welcome-sidebar {
  position: relative;
  z-index: 2;
  padding: 2rem 1rem;
  border-right: 1px solid rgba(227, 201, 145, 0.22);
  background:
    radial-gradient(ellipse at 0 0, rgba(89, 143, 78, 0.2), transparent 55%),
    rgba(5, 23, 14, 0.96);
}

.sidebar-brand {
  display: flex;
  align-items: center;
  gap: 0.7rem;
  margin: 0.25rem 0 2.5rem;
  padding: 0 0.5rem;
}

.sidebar-brand-mark {
  width: 2.35rem;
  height: 2.35rem;
  display: grid;
  place-items: center;
  border: 1px solid rgba(227, 201, 145, 0.55);
  border-radius: 0.75rem;
  background: rgba(227, 201, 145, 0.12);
  color: #e3c991;
  font-family: var(--font-heading);
  font-size: 1.3rem;
  font-weight: 700;
}

.sidebar-brand-name {
  display: grid;
  gap: 0.12rem;
  font-weight: 700;
  letter-spacing: 0.03em;
}

.sidebar-brand-name small {
  color: rgba(245,245,230,0.48);
  font-size: 0.58rem;
  letter-spacing: 0.2em;
}

.sidebar-caption {
  margin: 0 0 0.65rem 0.7rem;
  color: rgba(245,245,230,0.42);
  font-size: 0.65rem;
  font-weight: 700;
  letter-spacing: 0.16em;
}

.dashboard-link {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.85rem 0.8rem;
  border: 1px solid rgba(227, 201, 145, 0.3);
  border-radius: 0.65rem;
  color: #f7f5e8;
  font-weight: 600;
  text-decoration: none;
  background: linear-gradient(110deg, rgba(227, 201, 145, 0.13), rgba(255,255,255,0.025));
  box-shadow: inset 3px 0 #e3c991, 0 8px 24px rgba(0,0,0,0.15);
  transition: background 0.2s ease, border-color 0.2s ease, transform 0.2s ease;
}

.dashboard-icon {
  width: 1.85rem;
  height: 1.85rem;
  display: grid;
  place-items: center;
  border-radius: 0.5rem;
  background: rgba(227, 201, 145, 0.15);
  color: #e3c991;
  font-size: 1rem;
}

.dashboard-arrow {
  margin-left: auto;
  color: #e3c991;
  font-size: 1.4rem;
  line-height: 1;
}

.dashboard-link:hover {
  transform: translateX(2px);
  border-color: rgba(227, 201, 145, 0.62);
  background: linear-gradient(110deg, rgba(227, 201, 145, 0.22), rgba(255,255,255,0.05));
}

.welcome-main {
  position: relative;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: clamp(2rem, 8vw, 7rem);
  border: 1px solid rgba(227, 201, 145, 0.62);
  border-radius: 1.25rem;
  box-shadow:
    inset 0 0 0 1px rgba(227, 201, 145, 0.14),
    0 0 36px rgba(227, 201, 145, 0.12);
  background:
    linear-gradient(135deg, rgba(227, 201, 145, 0.12), transparent 38%, rgba(227, 201, 145, 0.05)),
    linear-gradient(90deg, rgba(5, 23, 14, 0.9), rgba(5, 23, 14, 0.48)),
    url('/seeu-coffee-stand.jpg') center / cover;
}

.welcome-logo {
  width: min(250px, 60vw);
  height: auto;
  margin-bottom: 2rem;
  filter: drop-shadow(0 10px 24px rgba(0,0,0,0.28));
}

.welcome-eyebrow {
  color: #b7d7a1;
  font-size: 0.75rem;
  font-weight: 700;
  letter-spacing: 0.18em;
}

.welcome-main h1 {
  margin: 0.7rem 0;
  font-family: var(--font-heading);
  font-size: clamp(2.5rem, 6vw, 4.5rem);
  letter-spacing: -0.045em;
}

.welcome-description {
  max-width: 430px;
  color: rgba(245,245,230,0.82);
  line-height: 1.7;
}

.order-button {
  display: inline-block;
  margin-top: 1.5rem;
  padding: 0.85rem 1.6rem 0.85rem 1.8rem;
  border: 1px solid rgba(227, 201, 145, 0.3);
  border-radius: 0.75rem;
  background: linear-gradient(110deg, rgba(227, 201, 145, 0.13), rgba(255,255,255,0.025));
  color: #f7f5e8;
  box-shadow: inset 3px 0 #e3c991, 0 8px 24px rgba(0,0,0,0.15);
  font-weight: 700;
  text-decoration: none;
  transition: background 0.2s ease, border-color 0.2s ease, transform 0.2s ease;
}

.order-button:hover {
  transform: translateX(2px);
  border-color: rgba(227, 201, 145, 0.62);
  background: linear-gradient(110deg, rgba(227, 201, 145, 0.22), rgba(255,255,255,0.05));
}

@media (max-width: 700px) {
  .welcome-page {
    grid-template-columns: 1fr;
    grid-template-rows: auto minmax(0, 1fr);
  }

  .welcome-sidebar {
    display: grid;
    grid-template-columns: 1fr auto;
    align-items: center;
    gap: 0.5rem 1rem;
    padding: 0.75rem 1rem;
    border-right: 0;
    border-bottom: 1px solid rgba(227, 201, 145, 0.22);
  }

  .sidebar-brand {
    margin: 0;
  }

  .sidebar-caption {
    display: none;
  }

  .dashboard-link {
    grid-column: 2;
    grid-row: 1;
    padding: 0.4rem 0.55rem;
    font-size: 0.85rem;
  }

  .dashboard-icon {
    width: 1.6rem;
    height: 1.6rem;
  }

  .dashboard-arrow {
    display: none;
  }

  .welcome-main {
    min-height: calc(100vh - 4.5rem);
    padding: 2rem;
  }
}
</style>
