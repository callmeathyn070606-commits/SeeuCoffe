<script setup>
import { ref } from 'vue'
import SplashScreen from '@/components/common/SplashScreen.vue'
import { useAuthStore } from '@/stores/auth'

const showSplash = ref(!useAuthStore().isLoggedIn)
</script>

<template>
  <SplashScreen v-if="showSplash" @complete="showSplash = false" />
  <router-view />
</template>
